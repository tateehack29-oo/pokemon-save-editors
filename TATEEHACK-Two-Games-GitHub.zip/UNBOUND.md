# Unbound Save Editor 0.1

Supported supplied Thai ROM SHA-256:
`403e50caa54501cc6184493cb5bcee5aeb8bca0e632e527a404d21ae5a0bc355`.
Test save: supplied Unbound v2.1.1.1, 131072 bytes. The newly attached ROM/save are byte-identical to the first pair.

## Features and limits

Save-only browser UI. Party (6) and PC (25 × 30), add to an empty slot, level, IV/EV, nature, ability, friendship, held item, moves, shiny, healing, money and coins, five bag pockets. 1,268 enabled species/forms with normal/shiny sprites, 922 moves and 728 items. Type-ahead move/item choices with item images. Original filenames/names and unknown bytes are preserved; export produces a new file.

This is a fixed profile, not automatic detection of arbitrary Unbound versions. Sector signatures/checksums alone cannot uniquely identify a ROM. Choose the editor matching the supplied build. Save States and other save sizes are unsupported. 128 KiB saves with a 16-byte trailer preserve the trailer.

Special modes that equalize/double/scale base stats block party stat-changing edits rather than calculate incorrect stats; PC editing and unrelated fields remain available. EV values up to 252 per stat, including pre-existing totals over 510, are supported. Battle-only forms and Z/Max moves may be reset or restricted by the game. No story/Pokédex/event unlocks. Full interactive play after import has not been tested.

## Native layout

- Footer signature 0x01121999; 14 sectors per alternating slot; newest complete counter selected with wrap handling. Checksums must match.
- Payload sizes: F24, FF0, FF0, FF0, D98, FF0 × 8, 450. Native table ROM 0xA6CD88.
- RAM mapping SB2 0x02024588; SB1 0x0202552C; storage 0x02029314. Extras from section0+F24, section4+D98, section13+450, physical sectors30/31 at 0x0203B174, 0x0203B240, 0x0203B498, 0x0203C038, 0x0203D028.
- Native box pointers ROM 0xA6CB2C. Boxes1–19 begin 0x02029318, 1,740 bytes each. Boxes20–25: 0x0203CB44, 0x0203D210, 0x0203D8DC, 0x02027434, 0x02027B00, 0x02024638. Box25 is not a disposable preset area.
- 100-byte party records; 58-byte unencrypted packed PC records. Four 10-bit moves occupy PC bytes39–43. Never apply standard Gen3 shuffled/XOR Pokémon codecs.
- Party count SB1+34; party SB1+38. Money SB1+290 XOR SB2+F20. Coins RAM 0x0203B814, plain u32. Native max 999,999,999.
- Bag native setup 0x089F4150/table0xA6BA08: items 0x0203BB20/450; keys 0x0203C228/75; balls 0x0203C354/50; TM/HM 0x0203C41C/128; berries 0x0203C61C/75. Quantities plain u16.
- Shiny XOR threshold16; nature PID%25; regular ability PID&1; hidden flag bit31 of IV word. Identity search preserves OT and gender.
- Names ROM166A98C, stats19E0C9C stride28; learnsets header43E20 pointers to three-byte move/level records. Move data A769AF stride12 (not old900000), names A40A10 stride13. Items876200 stride44. Front sprites1A1D5B4; palettes1A32BDC/1A3F77C. Palettes may be LZ-compressed.

## Validation

From project: `node tests/unbound/roundtrip.mjs /path/to/sample.srm /path/to/edited.srm`.
Tests preserve no-op bytes, all 180 original Pokémon, inactive slot, unrelated sectors and trailers. Tests edits, new Pokémon in every PC backing region, ordinary/cross-extra-sector records, party creation, bag/money/coins, corruption refusal, and creation of all 1,268 catalog entries.

`tests/unbound/native_verify.py` is an optional workspace-specific Unicorn harness (requires supplied ROM, fixtures generated under research/unbound, and Python Unicorn). Independently executes the ROM's getters for 206 edited/created party/PC records, and native stat recalculation/shiny, money and coins. DOM integration checked save-only opening, 25-box selection, exact-slot creation, export/reload, existing high-EV Pokémon edits, and type-ahead item/move selection. All 22,055 catalog image references across seven editors resolve.

## Sources / credits

Research: https://github.com/Zannael/PUSE (MIT), https://github.com/Skeli789/Complete-Fire-Red-Upgrade . PUSE's species constant/dex labels and item fallback names are used in extraction; license reproduced at `dist/unbound/licenses/PUSE-MIT.txt`. Its heuristic save writer was not used. Actual supplied ROM routines are authoritative. Existing project EXP helper/UI are reused. Pokémon names/art belong to their respective owners.

Extraction helper: `scripts/unbound/extract.py` (Pillow). The source ROM, user save and edited test saves are not distributed. Keep the whole dist tree together because unchanged images are shared across editors.
