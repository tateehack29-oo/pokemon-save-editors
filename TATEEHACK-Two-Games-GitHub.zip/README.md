# TATEEHACK — Pokémon Save Editors

หน้าแรกเลือก 2 เกม: ROWE 0.9 และ Wishes of Tomorrow 0.3

## นำขึ้น GitHub

แนะนำสร้าง repository ใหม่ เช่น pokemon-save-editors เพื่อให้เว็บ ROWE เดิมยังใช้ได้
1. แตก ZIP แล้วนำไฟล์และโฟลเดอร์ภายในขึ้น repository ให้ dist/index.html อยู่ตำแหน่งนี้โดยตรง
2. รวมโฟลเดอร์ .github/workflows ซึ่งอาจถูกซ่อนในตัวจัดการไฟล์
3. ไป Settings → Pages → Source เลือก GitHub Actions
4. ไป Actions → Deploy static content to Pages → Run workflow บน branch main
5. เปิด URL ที่แสดงในผล deployment

ZIP อย่างเดียวบน GitHub จะยังไม่เปิดเป็นเว็บ ต้องแตกไฟล์ก่อน และต้องอัปโหลด dist/ ให้ครบรวมรูปและไฟล์ .bin
ไฟล์นี้สำหรับ repository ใหม่ หากจะใช้ repository ROWE เดิม ต้องเปลี่ยน dist/ เป็นชุดนี้ทั้งหมดและตรวจ workflow เดิมก่อน
GitHub Pages จะเผยแพร่เว็บตามการตั้งค่าของ GitHub ไม่สืบทอดสิทธิ์ส่วนตัวจากเว็บ ChatGPT

## โครงสร้าง

- dist/index.html — หน้าเลือกเกม
- dist/wishes.html — Wishes of Tomorrow ThaiMod v1.0
- dist/rowe/index.html — ROWE TH Nonplae
- .github/workflows/static.yml — เผยแพร่ dist/ ผ่าน GitHub Pages
- docs/ — คู่มือเดิมและข้อมูลแหล่งที่มา

ทั้งสองตัวประมวลผลเซฟบนอุปกรณ์ ไม่ต้องใส่ ROM ไม่รวม ROM หรือเซฟผู้เล่นในชุดไฟล์
ตัวแก้เซฟทั้งสองใช้ข้อมูลเกมคนละชุด กรุณาเลือกให้ตรงกับเกม

ROWE source: https://github.com/tateehack29-oo/rowe-save-editor
Snapshot: 6f51cb90d6dbffec9ffd9b276063dc85dabf882d
คัดลอกตัวแก้เซฟ ROWE เดิมโดยเพิ่มเฉพาะลิงก์กลับหน้าเลือกเกม
ภาพ Pokémon และข้อมูลเกมเป็นของเจ้าของสิทธิ์เดิม ดูเครดิตใน docs/
