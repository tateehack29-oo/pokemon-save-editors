# TATEEHACK — Seven Pokémon GBA Save Editors

Homepage: `dist/index.html`. Includes ROWE, Wishes of Tomorrow, SoulGold, Quetzal, Super Dark Worship, Heart and Soul, and Unbound. Preserve the whole `dist/` directory: catalogs share image assets. Unbound documentation: `UNBOUND.md`. GitHub update instructions: `UPDATE-SEVEN-GAMES.txt`.

# Wishes of Tomorrow — ThaiMod v1.0 Save Editor 0.3

Client-side Thai-language mobile editor. `dist/` is the complete static site. No ROM, user save, or server-side file storage is included. All selected save bytes remain in browser memory; file downloads are new copies. Users no longer select a ROM.

## Supported build

ROM SHA-256: `a03357cac2f6f7e3bfe72ba1fc9dc137c55f79d684b948ba1ae1f36864c1ce07`.

The editor uses a bundled, fixed profile for that ROM. Save files must be 131072 bytes, contain a complete 14-sector save slot, and pass each sector checksum. Checksums validate structure and integrity, but cannot uniquely identify a game; users must select a Wishes of Tomorrow ThaiMod v1.0 save. The ROM identifies Expansion 1.15.3. Catalog data is extracted from this exact ROM. English constant names from the game's public source fill labels that use the Thai patch's custom character encoding. No Thai in-game names or text are rewritten.

## Features

- Money and Game Corner coins.
- Existing party and PC Pokémon: species, level, effective nature, native ability slot, friendship, held item, IVs, EVs, moves, shiny toggle, HP/PP/status healing.
- Bag item insertion, quantity editing and removal; correct pocket routing and encryption.
- Export `.sav` or `.srm`; original-save download and reset.
- Browse/search 1,579 enabled species/form records with normal/shiny sprites extracted from this ROM, including available female artwork. Species 1435 has no enabled data in this build and is excluded.
- Create a new Pokémon in the next party slot or an empty PC slot (specific slot or first empty slot in a selected box). Full/occupied destinations fail before any save mutation.
- Newly created Pokémon use the save owner’s raw OT name, trainer ID and gender, the selected species’ raw in-game nickname, native stats and level-up learnset. IV/EV/nature/gender/shiny settings are configurable. Location metadata inherits the first party member’s met location when available; quest and Pokédex flags are untouched.
- Uses modern shiny modifier and nature modifier bits; preserves personality, OT data, unknown bits, story/quest data, SaveBlock3 chunks, inactive slot and extra sectors.

## Verified binary layout

- SaveBlock2 3908 bytes; SaveBlock1 15572 bytes; storage 34144 bytes.
- Section payload 3968 bytes plus 116-byte SaveBlock3 tail and footer.
- Sector sizes `[3908,3968,3968,3968,3668,3968,3968,3968,3968,3968,3968,3968,3968,2400]`, directly confirmed in ROM at `0xCEDBE0`.
- Party count at SaveBlock1 `0x234`, party at `0x238`, money `0x490`, coins `0x494`, encryption key SaveBlock2 `0xAC`.
- Shiny threshold 256, modifier bit 14 at box record `0x1E`; confirmed in ROM getter at `0x1B41EE` and setter at `0x1B5286`.
- Species stride 260 at `0x701BF0`; item stride 44 at `0x6B0200`; move stride 68 at `0x6D0B14`; abilities stride 28 at `0xCC292C`.

Reference implementation reviewed: https://github.com/jmaloney95/Wishes-Game (`pokemon.h`, `pokemon.c`, `save.c`, `global.h`, ROM headers and constants). This ROM's offsets and checksums, rather than the source branch's changing layout, are authoritative.

## Validation

`node tests/engine.test.mjs /absolute/path/to/the-original-sample.sav`

The test expects the supplied sample (one Lv.5 Frigibax and 3300 money); sample bytes are intentionally external. Passed: exact no-op and unchanged-form roundtrips; money/items/stats/shiny changes; all 24 Pokémon encryption permutations; PC record crossing sector boundaries; save counter wrap; invalid-input rejection; inactive slot, SaveBlock3 and extra-sector preservation.

A DOM integration check also exercised ROM/save selection, strict ROM rejection, money save guard, Pokémon dialog, IV/shiny changes, item addition, downloaded-byte readback and reset. JavaScript syntax was checked.

Limitations: no emulator continuation test and no real mobile browser visual QA were available. Native WebMCP runtime validation was unavailable; optional tools are feature-detected and do not affect the editor. This release adds Pokémon only to empty slots. It does not update Pokédex flags or Shadow quest flags. Existing Pokémon names and gender remain unchanged; gender selection is supported for new Pokémon. Changing species preserves the existing nickname, capture data, tera type and other unexposed fields. Species forms are not automatically normalized. Keep an original save and test a copy in the game.

## Version 0.2 validation

`node tests/creation.test.mjs /absolute/path/to/the-original-sample.sav`

Passed creation of all 1,579 enabled species/form records at levels 1, 50 and 100; sprite availability; party and exact PC-slot insertion; OT/name/gender/shiny/stats/moves; cross-sector PC records; full party, full box and occupied-slot rejection; preservation of existing Pokémon.

The DOM integration flow passed save-only opening, catalog search (including Mega forms), normal/shiny artwork, adding to party, selecting an exact PC empty slot, export/reload, and editing existing Pokémon. No game-play continuation test was performed for these new additions. Some temporary forms may revert under the game’s native rules. Form entries alone do not set independent Shadow/purification quest state.

Sprite assets are extracted with the game’s Smol decompression routines adapted from `src/decompress.c`, using this ROM’s own front sprites and palettes. Artwork credit remains with the game and its contributors; https://github.com/jmaloney95/Wishes-Game lists credits.

## Version 0.3

Held items, bag items, and each of the four move slots now use immediate inline search suggestions. Users type part of a name or an exact ID and tap a result; keyboard arrows/Enter and Escape are supported. Pending search text cannot silently save the previous selection. Moves display type, power, accuracy and PP.

All 923 item records reference bundled icons extracted from this ROM's item picture and palette tables. Entries without native artwork use the game's fallback icon. Images appear in item suggestions, the selected item field, and bag rows.

DOM integration passed live filtering, item images, independent move slots, keyboard selection, invalid-query rejection, Escape restore, bag addition and exported-save readback. The party/PC creation integration flow was rerun successfully. All item asset references and JavaScript syntax passed checks. Real mobile browser visual QA remains unavailable.

## Shared game selection

The root page now selects ROWE 0.9, Wishes 0.3, SoulGold 0.1, or Quetzal 0.1. Wishes moved to wishes.html with its original relative assets. ROWE is bundled in rowe/ from public repository commit 6f51cb90d6dbffec9ffd9b276063dc85dabf882d; only its index gains back navigation. The exported GitHub package contains all four complete static editors and a Pages workflow. Original ROWE repository is unchanged. Validated local links/assets, unchanged ROWE engine bytes, Wishes creation/search/export integration.

## SoulGold GBA

See [SOULGOLD.md](SOULGOLD.md) for the separate fixed-profile SoulGold editor and validation.

## Quetzal GBA

See [QUETZAL.md](QUETZAL.md) for the separate fixed-ROM profile, supported storage modes and native validation.


## Super Dark Worship

The fifth editor is at `dist/darkworship/`. See [DARKWORSHIP.md](DARKWORSHIP.md) for supported ROM, binary profile, validation and limitations. The five-game homepage retains the support popup.
