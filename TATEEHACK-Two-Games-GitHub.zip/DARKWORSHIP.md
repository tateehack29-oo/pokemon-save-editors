# Super Dark Worship TH Nonplae — Editor 0.1

The fifth game at `dist/darkworship/`. Browser-only save editing; no ROM upload is required. Supported supplied ROM SHA-256: `fb792ee7a3e161f28865470eec53bd527f2adeacd2acf5437a173ad64cc07131`.

Features: money, coins, five expanded bag pockets with item pictures, live held-item/move suggestions, existing party/PC editing, party/PC creation, 14 boxes, level, nature, native ability slots, shiny, friendship, held item, moves, IVs/EVs and healing. 1,410 usable species/form records, 982 move records, 750 item records. Native ROM name/ID labels are used; some extra forms are distinguished by internal ID when a verified long form name is unavailable. Does not edit story progress or Pokédex flags.

## Verified structure

- FireRed/CFRU unencrypted, unshuffled 80-byte box / 100-byte party Pokémon. Checksums/shuffling/encryption are disabled by this ROM; do not apply a standard Gen III encrypted codec. Hidden ability uses bit 31 of IV word, regular ability uses personality parity. Nature is personality modulo 25; shiny XOR threshold is 8. Preserve gender when changing personality.
- Save section data sizes: `[3876,4080,4080,4080,3480,4080,4080,4080,4080,4080,4080,4080,4080,1104]` from ROM table 0x1237D5C. Native section signature is 0x08012025.
- Money/coins: SaveBlock1 0x290/0x294, security key at SaveBlock2 0xF20. Party count/data: 0x34/0x38. PC records start at 4, 420 slots.
- Expanded inventory is in the native parasite region: tails of sections 0/4/13 followed by 4080-byte payloads in sectors 30/31. It is distinct from the vanilla bag. Pocket offsets in reconstructed parasite: 0x9AC/0x10B4/0x11E0/0x12A8/0x14A8; capacities 450/75/50/128/75. Quantities are plaintext, verified against native getters. Preserve all unrelated parasite bytes and both extension sector footers. Native checksum covers only the declared main section, not parasite tails.
- This ROM uses a custom EXP table, including medium-slow level 5 = 134. Read the exact native table at 0x123C484; do not calculate vanilla formulas.
- Species: 0x1902BA8, 28-byte records; names 0x151FC98 stride 11; moves 0x123960E stride 12; move names 0x11FF454 stride 13; items 0x13C0000 stride 44; learnset pointer at 0x43E20, 3-byte entries.

## Validation

`node tests/darkworship.test.mjs /path/to/input.sav /tmp/edited.sav /tmp/vectors.json`

Passed byte-identical unedited export, original Pokémon no-op, original Fennekin level 5 and money 3000, all five pockets, changes/reload, party creation, insertion into final PC slot, occupied-slot/EV validation, inactive bank/Hall of Fame preservation, and optional 16-byte emulator trailer. All 1,410 enabled species were created at levels 1, 50 and 100 (4,230 cases), including shiny/nature checks and artwork reference validation.

Native ARM execution of the supplied ROM independently verified edited money and all five pocket quantities, checksums for all 14 sections, and 55 representative Pokémon vectors against the game's species/ability/shiny/stat/default-move routines. UI integration passed loading, form search, exact PC slot insertion, downloads/readback, live item/move search, images, keyboard selection and invalid-query handling.

No full emulator gameplay continuation or mobile visual test was performed. The native normal-mode formulas were validated; randomizer and special battle-facility modes have not been validated. Only the supplied ROM version is supported, and save checksums cannot conclusively identify the game. Keep the original save. One malformed battle sprite in the ROM (Tatsugiri #1405) is represented by its native menu icon, also in shiny preview. No ROM or user save is included in the website or distribution.

Reference structures: https://github.com/Skeli789/Complete-Fire-Red-Upgrade and https://github.com/pret/pokefirered . Supplied ROM code takes precedence over upstream sources. Artwork remains credited to Pokémon and ROM hack contributors.
