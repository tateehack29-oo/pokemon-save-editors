# Pokémon Quetzal TH Nonplae · Editor 0.3

This is a fixed-ROM-profile editor for the uploaded 32 MiB Thai Quetzal build.
ROM SHA-256: `dbc5100a2558077c3b2c0e4c18ae4a39b0ce48b2481ca702bf790c25f7bea010`.
The ROM and the user's save are not included in the website or ZIP. Processing is local in the browser; no ROM selection is required.

Features: money/coins, Party and PC editing/insertion, level, nature, ability slot, friendship (Party), held item, moves, IV/EV, normal/Shiny/Radiant, Party healing, BAG3 inventory with item quantities/removal. Live item and move suggestions include native item artwork. The catalog has 1,528 species/form records, 848 moves plus None, 889 items plus None, and 318 abilities plus None, extracted from this exact ROM. Form labels use native flags where available and explicit record IDs for unnamed forms.

Native front/shiny sprite tables supply the artwork. Kilowattrel uses a matching SoulGold fallback because this build's palette stream did not decode reliably. The 890 item records use the Quetzal icon table at `0x12BD4B8`; item 107 uses the game's unknown-item icon on decompression failure. All artwork belongs to its respective creators.

## Format and preservation

- Two banks of 16 × 4096-byte sectors. Section sizes `[1560, ...14 × 3968, 3652]`, footer signature `0x08012025`. Latest complete bank must pass checksums.
- SaveBlock2: 1560 bytes. SaveBlock1: 15872 bytes. Storage: 43332 bytes. Trailing 16 emulator bytes, inactive bank, unused tails, trainer names and story fields are preserved.
- Party count `SB1+0x6A4`, records `SB1+0x6A8`, 104 bytes each. Money `+0x918`, coins `+0x91C`, key `SB2+0x2C`.
- Storage starts at `+0x461`, with 31-byte compressed Pokémon/45 boxes in the provided save. Also supports the 21-byte/no-nickname option with 67 boxes. Also supports 38-byte/37-box and 28-byte/50-box modes retaining HP, status and PP. Their nickname field, where present, starts at byte 28. Unedited battle state is preserved.
- PC EXP uses units of 10; level changes round to the next representable EXP. Exact native growth tables are bundled, including Quetzal's rounded growth values. PC EVs use units of 4. Friendship is not stored in this PC format and cannot be edited there. Unknown compressed bits/nicknames are preserved.
- BAG3 v2 has 25-bit normal records (11-bit item ID, 14-bit encrypted quantity) and 11-bit key-item records. Records span two logical SB1 ranges. Active-prefix and total counts are maintained, including inactive suffix entries. Key items route to native pocket 11, one copy; other quantities max 9999.

## Validation

Run from repository root:

```
QUETZAL_SAVE=/absolute/path/to/the-provided-save.sav node tests/quetzal.test.mjs
```

The test runs without the environment variable for catalog and all-species creation checks. With the external sample, it checks byte-identical no-op/unchanged dialog roundtrips, money, Party mutation/insertion, first/middle/last PC insertion, occupied/full rejection, bag mutation, checksum rejection and inactive bank preservation. It does not write to the input save.

Additional local validation executed native ARM routines from the supplied ROM under Unicorn: BAG3 validation/quantity/key lookups, compressed PC decoding through the game's storage dispatcher, and Party stat recalculation. Native comparisons covered normal/Shiny/Radiant packed fields, IVs, EVs and moves. A DOM integration test covered file opening, type-ahead and keyboard selection, invalid-query rejection, item artwork, Party/PC addition, export and readback.

No full emulator gameplay continuation test has been performed. Only the original ROM profile and the verified text-only update are supported; valid checksums alone cannot prove ROM identity. Existing nicknames and unexposed capture/form metadata are preserved when changing species. Temporary forms can revert under game rules. Pokédex/story flags are not automatically modified.

## 0.2 compatibility fix

Verified updated ROM SHA-256: `9cff247d73c50c2029ffa8d7cb8f1350415852b789259ab5aa00822f3dfc2329`. The updated upload differs in 12 text bytes only; the save, catalog and codec routines are identical.

The second supplied save uses 37-box battle-state storage and legacy inventory. All four native PC sizes (21/28/31/38) now work. Legacy inventory is parsed using the native importer ranges and option flags. A no-op or Pokémon-only edit leaves legacy inventory bytes untouched. An inventory edit converts the bag to BAG3 as the supplied ROM itself does. Conversion bytes were compared against execution of the ROM's importer and matched exactly.

Malformed/Bad Egg Party slots are displayed as protected placeholders. They cannot be edited; exporting other edits preserves their bytes. This is not a recovery or deletion of malformed Pokémon. The second sample contains such a record in Party slot 2. Its latest complete bank is selected; its other incomplete bank is left untouched.

`QUETZAL_PROBLEM_SAVE=/path/to/problem.sav node tests/quetzal-compat.test.mjs` tests exact no-op, preserved bad slot and battle fields, old/new bags, all four storage formats, and mutation readback. Native execution of the updated ROM independently verified the stored HP, status, PP, nickname, EXP, species, calculated maximum HP and bag item counts. DOM integration opened the problem save, showed 37 boxes and the protected slot, edited/healed a PC Pokémon, then verified downloaded bytes. Original-sample regression checks also passed. Full emulator gameplay continuation remains untested.


## 0.3 — combined Shiny + Radiant

Four color modes: normal (0), Shiny (1), Radiant (2), and Shiny + Radiant (3).
Party personality byte 1 uses two independent low bits; cached flags in byte 19 use bits 3 and 4. Compressed PC records use bits 44 and 45. Combined records now load without rejection or collapsing to Radiant, and edits preserve both flags. Boolean shiny/radiant values expose the respective bit.

Verified against ROM SHA-256 `9cff247d73c50c2029ffa8d7cb8f1350415852b789259ab5aa00822f3dfc2329`: executed the native storage dispatcher at ROM offset 0x134490 for all 16 combinations of four colors and 21/28/31/38-byte PC records. The ROM reconstructed both personality bits and cached flags correctly, including value 3. The supplied latest save contains no known combined-color specimen; testing used generated records and edited copies, not a naturally caught example.

`node tests/quetzal-colors.test.mjs /path/to/sample.sav` checks no-op, all mode transitions in 88/104-byte and four compressed layouts, preservation of unrelated record bytes and inactive bank, Party/PC insertion, and rejection of invalid colors. Existing catalog/compression regressions passed. DOM integration checked four options, both Party and PC edits, labels, reopening, and download/readback.

Radiant artwork is not reproduced by the current preview assets. The editor explicitly marks this limitation when Radiant or combined mode is selected. Full emulator gameplay continuation was not performed for this update.
