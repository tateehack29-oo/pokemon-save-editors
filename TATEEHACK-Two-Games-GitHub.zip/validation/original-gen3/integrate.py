from pathlib import Path
import json,re,shutil
root=Path('original-gen3');dist=root/'dist';cards=[]
for i,(slug,title,cover,style) in enumerate([('emerald','Emerald','Rayquaza','rowe'),('ruby','Ruby','Groudon','darkworship'),('sapphire','Sapphire','Kyogre','soulgold')],21):
 c=json.loads((dist/slug/'catalog.json').read_text());sp=next(s for s in c['species'] if s['name'].lower()==cover.lower());shutil.copyfile(dist/slug/sp['sprite'],dist/slug/'cover.webp')
 cards.append(f'<a class="game {style}" data-platform="gba" href="{slug}/"><div class="card-top"><span class="number">{i}</span><span class="version">GBA · EDITOR 0.1</span></div><div class="art"><img src="{slug}/cover.webp" alt="{cover}" width="160" height="160"></div><div class="game-info"><p class="series">POKÉMON</p><h2>{title}</h2><p class="build">Original · GBA · เซฟ 128 KB</p><span class="launch">เปิดตัวแก้เซฟ <span aria-hidden="true">↗</span></span></div></a>')
 p=dist/slug/'index.html';s=p.read_text().replace('</body>',f'<script src="../analytics-config.js?v=gen3original1" defer></script><script src="../analytics.js?v=gen3original1" data-game="{slug}" defer></script></body>');p.write_text(s)
 p=dist/slug/'engine.mjs';s=p.read_text();s=re.sub(r'// Girls Hunter 3[^\n]*','// Original '+title+' ROM: catalog, stat calculation and save sections verified.',s);p.write_text(s)
p=dist/'index.html';s=p.read_text();needle='</div></section><noscript>';assert needle in s;s=s.replace(needle,'\n'.join(cards)+'\n'+needle).replace('GBA 18 เกม','GBA 21 เกม').replace('data-count="gba">18 เกม','data-count="gba">21 เกม');p.write_text(s)
p=dist/'admin/app.mjs';s=p.read_text().replace("radicalred:'Pokémon Radical Red 4.1'","radicalred:'Pokémon Radical Red 4.1',emerald:'Pokémon Emerald',ruby:'Pokémon Ruby',sapphire:'Pokémon Sapphire'");p.write_text(s)
p=dist/'admin/index.html';s=p.read_text();s=re.sub(r'app.mjs\?v=[\w-]+','app.mjs?v=gen3original1',s);p.write_text(s)
p=root/'analytics-backend/worker.mjs';s=p.read_text().replace("'radicalred'];","'radicalred','emerald','ruby','sapphire'];");p.write_text(s)
(root/'ORIGINAL-GEN3-UPDATE-TH.txt').write_text('''เพิ่ม Pokémon Emerald / Ruby / Sapphire เวอร์ชันต้นฉบับ ในหน้า GBA
รวมเกมสาธารณะ 23 ภาค: GBA 21 ภาค + NDS 2 ภาค และ Private Editor 2 ภาคเดิม

วิธีอัปเดต: เปลี่ยนชื่อ ZIP นี้เป็น TATEEHACK-Two-Games-GitHub.zip แล้วอัปโหลดแทนไฟล์เดิม Commit / Push รอ Actions สำเร็จ

รองรับผู้เล่น ชื่อ เงิน เหรียญ ทีม PC 14 กล่อง เพิ่มโปเกมอน Nature IV EV ท่า Ability Shiny และกระเป๋าพร้อมรูปไอเทม
ส่งออก .sav / .srm ขนาดเดิมหรือมาตรฐาน 128 KB รองรับเซฟถึง 64 MB หากเซฟถูกต้องอยู่ต้นไฟล์
Ruby/Sapphire ใช้รูปไอเทม Emerald ที่จับคู่ตามชื่อ; รูปโปเกมอนและข้อมูลอื่นอ่านจาก ROM แต่ละภาค

ผลตรวจ: เซฟจริงทั้งสามภาคเปิดและส่งออกโดยไม่เปลี่ยนข้อมูลได้ แก้ไขแล้วเปิดซ้ำผ่าน เก็บ backup bank และข้อมูลท้ายไฟล์ครบ
ตรวจ native getter / คำนวณค่าสถานะกับ ROM ของแต่ละภาคครบ 386 สายพันธุ์ และตรวจ checksum ทั้งสอง bank ผ่าน
ยังไม่ได้ทดสอบ Safari หรือเล่นต่อในอีมูเลเตอร์จริง
ROM และไฟล์เซฟของผู้ใช้ไม่ถูกรวมในชุดเว็บ

อัปเดตสถิติ Cloudflare (เพื่อให้สามภาคใหม่ถูกนับ)
เปิด Worker tateehack-analytics > Edit code
แก้เฉพาะคำสั่ง const games ด้านบนเป็นบรรทัดนี้ แล้ว Deploy (ถ้าใน Worker ของคุณใช้ชื่อ GAMES ให้คงชื่อตัวแปรเดิม)
'''+s.splitlines()[0]+'\nไม่ต้องเปลี่ยนรหัส Admin หรือฐานข้อมูล\n')
