from pathlib import Path
import zipfile,re,json,posixpath
root=Path('original-gen3');slugs=['emerald','ruby','sapphire'];changed=['dist/index.html','dist/admin/index.html','dist/admin/app.mjs','analytics-backend/worker.mjs']
out=Path('TATEEHACK-23-Games-Emerald-Ruby-Sapphire.zip')
with zipfile.ZipFile('TATEEHACK-Private-Halloween.zip') as old,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,9) as z:
 for info in old.infolist():z.writestr(info,(root/info.filename).read_bytes() if info.filename in changed else old.read(info.filename))
 for slug in slugs:
  for p in (root/'dist'/slug).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(root).as_posix())
 z.write(root/'ORIGINAL-GEN3-UPDATE-TH.txt','ORIGINAL-GEN3-UPDATE-TH.txt')
 for name in ['build.py','test.mjs','native.py','integrate.py','package.py']:z.write(root/'validation'/name,'validation/original-gen3/'+name)
with zipfile.ZipFile(out) as z,zipfile.ZipFile('TATEEHACK-Private-Halloween.zip') as old:
 assert z.testzip() is None;names=set(z.namelist())
 assert set(n for n in old.namelist() if old.read(n)!=z.read(n))==set(changed)
 page=z.read('dist/index.html').decode();assert len(re.findall('data-platform="gba"',page))==21;assert len(re.findall('data-platform="nds"',page))==2
 admin=z.read('dist/admin/index.html').decode();assert '../private-girlshunter3/' in admin and '../private-girlshunterhalloween/' in admin
 for slug in slugs:
  base='dist/'+slug+'/'
  for n in names:
   if not n.startswith(base):continue
   assert not n.endswith(('.gba','.sav','.srm'))
   if n.endswith('.mjs'):
    for link in re.findall(r'(?:from\s*|import\s*)[\'"]([^\'"]+)',z.read(n).decode()):assert posixpath.normpath(posixpath.join(posixpath.dirname(n),link.split('?')[0])) in names
  html=z.read(base+'index.html').decode();ids=re.findall(r'\bid="([^"]+)"',html);assert len(ids)==len(set(ids));assert 'data-game="'+slug+'"' in html
  cat=json.loads(z.read(base+'catalog.json'))
  for sp in cat['species']:
   if sp.get('sprite'):assert base+sp['sprite'] in names
  for it in cat['items']:
   if not it['unavailable']:assert it.get('sprite') and base+it['sprite'] in names,(slug,it)
 print('PASS ZIP CRC, 23 public games (21 GBA/2 NDS), both Private editors, all assets and dependencies, unchanged previous editors')
print(out.resolve(),out.stat().st_size)
