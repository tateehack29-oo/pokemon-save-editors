import json,struct
from pathlib import Path
from unicorn import *
from unicorn.arm_const import *
for slug,fn,getter,stats,checksum in [('emerald','Emerald Version (USA, Europe)',0x6a674,0x68d0c,0x153164),('ruby','Ruby Version (USA)',0x3cbfc,0x3b1b8,0x125c10),('sapphire','Sapphire Version (USA)',0x3cbfc,0x3b1b8,0x125c10)]:
 r=Path('upload/Pokemon - '+fn+'.gba').read_bytes();u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
 for a,n in [(0x8000000,0x2000000),(0x2000000,0x40000),(0x3000000,0x10000),(0x4000000,0x1000),(0x5000000,0x1000),(0x6000000,0x20000)]:u.mem_map(a,n)
 u.mem_write(0x8000000,r)
 def call(addr,*args):
  for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(reg,v)
  u.reg_write(UC_ARM_REG_SP,0x300f000);u.reg_write(UC_ARM_REG_LR,0x300fff1);u.emu_start((addr+0x8000000)|1,0x300fff0,count=2000000);assert u.reg_read(UC_ARM_REG_PC)==0x300fff0;return u.reg_read(UC_ARM_REG_R0)
 for v in json.loads(Path('original-gen3/validation/'+slug+'-vectors.json').read_text()):
  a=0x2018000;u.mem_write(a,bytes(v['raw']).ljust(100,b'\0'))
  for k,f in {'species':11,'heldItem':12,'exp':25,'friendship':32,'ability':46}.items():assert call(getter,a,f,0x2010000)==v['expected'][k],(slug,k,v['expected']['species'])
  for k,start in [('moves',13),('ivs',39),('evs',26)]:
   for i,n in enumerate(v['expected'][k]):assert call(getter,a,start+i,0x2010000)==n,(slug,k,i,n)
  if v['stats']:
   call(stats,a);got=bytes(u.mem_read(a+84,16));assert got==bytes(v['stats']),(slug,v['expected']['species'],got.hex(),bytes(v['stats']).hex())
 sizes=[3884 if slug=='emerald' else 2192,3968,3968,3968,3848 if slug=='emerald' else 3136]+[3968]*8+[2000]
 save=Path('original-gen3/validation/'+slug+'-edited.sav').read_bytes()
 for i in range(28):
  b=save[i*4096:(i+1)*4096];id=struct.unpack_from('<H',b,4084)[0]
  u.mem_write(0x2010000,b[:sizes[id]]);assert call(checksum,0x2010000,sizes[id])==struct.unpack_from('<H',b,4086)[0]
 print(slug,'PASS ROM native getters, calculated stats (386 species), both-bank section checksums')
