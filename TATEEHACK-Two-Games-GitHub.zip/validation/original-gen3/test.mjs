import fs from 'node:fs';import assert from 'node:assert/strict';
for(const [slug,fn] of [['emerald','Emerald Version (USA, Europe)'],['ruby','Ruby Version (USA)'],['sapphire','Sapphire Version (USA)']]){
 const {SaveEditor,POCKETS,SIZES,encodeMon,decodeMon,createPokemon}=await import('../dist/'+slug+'/engine.mjs');
 const c=JSON.parse(fs.readFileSync('original-gen3/dist/'+slug+'/catalog.json')),b=new Uint8Array(fs.readFileSync('upload/Pokemon - '+fn+'.sav')),e=new SaveEditor(b,c);
 assert.deepEqual(e.export(),b);const vectors=[];
 const vector=raw=>{const m=decodeMon(raw,c);vectors.push({raw:[...raw],expected:{species:m.species,heldItem:m.heldItem,moves:m.moves,exp:m.exp,ivs:m.ivs,evs:m.evs,ability:m.ability,friendship:m.friendship},stats:raw.length===100?[...raw.slice(84)]:null});};
 for(const p of [{},{level:50,heal:true},{nature:3,ivs:[31,31,31,31,31,31],evs:[6,252,0,252,0,0],heal:true},{species:19,ability:1,shiny:true,heldItem:1,moves:[1,43,10,0],friendship:255},{species:6,level:100,nature:15,heal:true},{species:303,level:50,heal:true}])vector(encodeMon(e.mon('party:0').raw,p,c));
 for(const sp of c.species.filter(x=>x.base[0]))vector(createPokemon({species:sp.id,level:50,nature:sp.id%25},{id:123,name:e.sb2.slice(0,7),gender:0},c,()=>0x12345678));
 for(const p of POCKETS){const it=c.items.find(x=>x.id&&x.pocket===p.id&&!x.unavailable);e.addItem(it.id,it.importance?1:10);assert(e.items(p.id).some(x=>x.id===it.id&&x.quantity===(it.importance?1:10)));}
 const count=e.partyCount;e.setMoney(123456);e.setCoins(999);e.setTrainerName('OOTEE');e.addPokemon({species:19,level:20},{destination:'party'});e.addPokemon({species:201,level:30},{destination:'pc',box:13,slot:29});
 const out=e.export(),again=new SaveEditor(out,c);assert.equal(again.money,123456);assert.equal(again.coins,999);assert.equal(again.trainer,'OOTEE');assert.equal(again.partyCount,count+1);assert.equal(again.mon('pc:419').level,30);vector(again.mon('party:'+count).raw);vector(again.mon('pc:419').raw);
 const inactive=e.slot===0?14*4096:0;assert.deepEqual(out.slice(inactive,inactive+14*4096),b.slice(inactive,inactive+14*4096));
 for(const [id,o] of e.sectors)assert.deepEqual(out.slice(o+SIZES[id],o+4084),b.slice(o+SIZES[id],o+4084));
 for(const size of [131088,1024*1024,64*1024*1024]){const big=new Uint8Array(size);big.set(b);big.fill(42,131072);const x=new SaveEditor(big,c);assert.deepEqual(x.export(),big);x.setMoney(555);const changed=x.export();assert.equal(changed.length,size);assert.deepEqual(changed.slice(131072),big.slice(131072));assert.equal(x.export({size:'standard'}).length,131072);}
 const broken=b.slice();broken[e.sectors.get(0)]^=1;assert.throws(()=>new SaveEditor(broken,c));
 for(const s of c.species.filter(s=>s.base[0])){for(const k of ['sprite','shinySprite'])assert(fs.existsSync('original-gen3/dist/'+slug+'/'+s[k]));for(const [l,m] of s.learnset)assert(c.moves[m]);}
 fs.writeFileSync('original-gen3/validation/'+slug+'-vectors.json',JSON.stringify(vectors));fs.writeFileSync('original-gen3/validation/'+slug+'-edited.sav',out);
 console.log(slug,'PASS original, edits, bag, rename, party/PC, bank/trailer preservation, oversized, corruption, assets');
}
