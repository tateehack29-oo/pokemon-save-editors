from pathlib import Path
import re,struct,json,hashlib,shutil
base=Path('admin-source/validation/girlshunter3/build.py').read_text().split("for f in ['engine.mjs'")[0]
for slug,title,fn,addr in [
('emerald','Emerald','Emerald Version (USA, Europe)',[0x3185c8,0x3203cc,0x301418,0x303678,0x304438,0x32937c,0x31c898,0x31977c,0x31b6db,0x5839a0,0x614410,0x31f72c]),
('ruby','Ruby','Ruby Version (USA)',[0x1f716c,0x1fec18,0x1e8354,0x1ea5b4,0x1eb374,0x207bc8,0x1fb12c,0x1f8320,0x1fa248,0x3c5564,0,0x1fdf78]),
('sapphire','Sapphire','Sapphire Version (USA)',[0x1f70fc,0x1feba8,0x1e82e4,0x1ea544,0x1eb304,0x207b58,0x1fb0bc,0x1f82b0,0x1fa1d8,0x3c55bc,0,0x1fdf08])]:
 old=[0x245ee0,0x254784,0x2350ac,0x23730c,0x2380cc,0x25d7b4,0x250c04,0x247094,0x24fc40,0x3db028,0x3d4294,0x253ae4]
 s=base.replace("Path('validation/lazarus/build.py')","Path('admin-source/validation/lazarus/build.py')")
 s=s.replace("Path('../upload/Girls Hunter 3 Version.gba')",f"Path('upload/Pokemon - {fn}.gba')")
 s=s.replace("Path('dist/private-girlshunter3')",f"Path('original-gen3/dist/{slug}')")
 s=s.replace("Path('dist/fireredrocket/catalog.json')","Path('original-gen3/dist/fireredrocket/catalog.json')")
 s=s.replace("'Pokémon Girls Hunter 3'",repr('Pokémon '+title))
 for a,b in zip(old,addr):s=s.replace(hex(a),hex(b))
 count=377 if slug=='emerald' else 349;s=s.replace('range(375)',f'range({count})')
 if slug!='emerald':
  s=s.replace("sprite(u32(0x0+i*8),u32(0x0+i*8+4),24)","None")
 ns={};exec(s,ns);c=ns['c'];r=ns['r'];out=ns['out']
 if slug!='emerald':
  ec=json.loads(Path('original-gen3/dist/emerald/catalog.json').read_text());byname={x['name']:x for x in ec['items']}
  for item in c['items']:
   match=byname.get(item['name'])
   if match and match.get('sprite'):
    item['sprite']=match['sprite'];shutil.copyfile(Path('original-gen3/dist/emerald')/item['sprite'],out/item['sprite'])
 (out/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')))
 for f in ['engine.mjs','app.mjs','index.html','style.css','pickers.mjs']:
  t=Path('original-gen3/dist/private-girlshunterhalloween',f).read_text().replace('Girls Hunter Halloween',title).replace('GIRLS HUNTER HALLOWEEN',title.upper()).replace('halloween1',slug+'1')
  if f=='engine.mjs':
   t=re.sub(r"ROM_SHA256='[^']+'","ROM_SHA256='"+c['romSha256']+"'",t)
   sizes=[3884 if slug=='emerald' else 2192,3968,3968,3968,3848 if slug=='emerald' else 3136]+[3968]*8+[2000]
   t=re.sub(r'export const SIZES=\[.*?\];','export const SIZES='+json.dumps(sizes)+';',t)
   offsets=[0x560,0x5d8,0x650,0x690,0x790] if slug=='emerald' else [0x560,0x5b0,0x600,0x640,0x740]
   counts=[30,30,16,64,46] if slug=='emerald' else [20,20,16,64,46]
   pockets=[{'id':i,'name':name,'offset':o,'count':n} for i,(name,o,n) in enumerate(zip(['ไอเทม','ของสำคัญ','โปเกบอล','TM / HM','เบอร์รี'],offsets,counts))]
   t=re.sub(r'export const POCKETS=\[.*?\];','export const POCKETS='+json.dumps(pockets,ensure_ascii=False)+';',t)
   t=t.replace('new Uint8Array(15720)',f'new Uint8Array({sum(sizes[1:5])})').replace('u32(this.sb2,0xf20)','u32(this.sb2,0xac)' if slug=='emerald' else '0')
   for a,b in [('0x290','0x490'),('0x294','0x494'),('0x34','0x234'),('0x38','0x238')]:t=t.replace(a,b)
   t=t.replace('(4<<7)|(4<<11)',f'(4<<7)|({3 if slug=="emerald" else 2 if slug=="ruby" else 1}<<11)')
   exp=[list(struct.unpack_from('<101I',r,addr[-1]+i*404)) for i in range(6)];t=re.sub(r'const EXP_TABLE=.*?;','const EXP_TABLE='+json.dumps(exp,separators=(',',':'))+';',t)
  if f=='index.html':t=t.replace('href="../admin/"','href="../#gba"').replace('← กลับหน้า Admin','← เลือกเกม').replace('TATEEHACK / PRIVATE EDITOR','TATEEHACK / SAVE EDITOR')
  (out/f).write_text(t)
 print(slug,'extracted',len(c['items']), 'items')
