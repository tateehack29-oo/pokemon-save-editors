from pathlib import Path
import json,re,shutil,zipfile,posixpath
root=Path('frlg');d=root/'dist';cards=[]
for n,(slug,title,cover,style) in enumerate([('firered','FireRed','Charizard','darkworship'),('leafgreen','LeafGreen','Venusaur','rowe')],24):
 c=json.loads((d/slug/'catalog.json').read_text());sp=next(s for s in c['species'] if s['name'].lower()==cover.lower());shutil.copyfile(d/slug/sp['sprite'],d/slug/'cover.webp')
 cards.append(f'<a class="game {style}" data-platform="gba" href="{slug}/"><div class="card-top"><span class="number">{n}</span><span class="version">GBA · EDITOR 0.1</span></div><div class="art"><img src="{slug}/cover.webp" alt="{cover}" width="160" height="160"></div><div class="game-info"><p class="series">POKÉMON</p><h2>{title}</h2><p class="build">Original · GBA · เซฟ 128 KB</p><span class="launch">เปิดตัวแก้เซฟ <span aria-hidden="true">↗</span></span></div></a>')
p=d/'index.html';s=p.read_text().replace('</div></section><noscript>','\n'.join(cards)+'\n</div></section><noscript>').replace('GBA 21 เกม','GBA 23 เกม').replace('data-count="gba">21 เกม','data-count="gba">23 เกม');p.write_text(s)
p=d/'admin/app.mjs';s=p.read_text().replace("sapphire:'Pokémon Sapphire'","sapphire:'Pokémon Sapphire',firered:'Pokémon FireRed',leafgreen:'Pokémon LeafGreen'");p.write_text(s)
p=d/'admin/index.html';s=re.sub(r'app.mjs\?v=[\w-]+','app.mjs?v=frlg1',p.read_text());p.write_text(s)
p=root/'analytics-backend/worker.mjs';s=p.read_text().replace("'sapphire'];","'sapphire','firered','leafgreen'];");p.write_text(s)
(root/'FIRERED-LEAFGREEN-UPDATE-TH.txt').write_text('''เพิ่ม FireRed และ LeafGreen เวอร์ชันต้นฉบับ USA ในหน้า GBA
รวม 25 เกมสาธารณะ (GBA 23 + NDS 2) และ Private Editor 2 ภาคเดิม

อัปเดต: เปลี่ยนชื่อ ZIP เป็น TATEEHACK-Two-Games-GitHub.zip อัปโหลดแทนไฟล์เดิม Commit/Push แล้วรอ Actions สำเร็จ
รองรับผู้เล่น ชื่อ เงิน เหรียญ ทีม PC 14 กล่อง เพิ่มโปเกมอน Nature IV EV ท่า Ability Shiny และกระเป๋าพร้อมรูป
รองรับ .sav/.srm ขนาด 128 KB ถึง 64 MB เมื่อส่วนเซฟที่ตรวจสอบได้อยู่ต้นไฟล์
ส่งออกขนาดเดิมเก็บข้อมูลท้ายไฟล์ หรือเลือกมาตรฐาน 128 KB

ทดสอบกับเซฟที่ผู้ใช้ส่งมาทั้งสองภาค: เปิด/ส่งออกโดยไม่เปลี่ยนข้อมูล แก้ไขเงิน ไอเทม ชื่อ ทีม/PC แล้วเปิดใหม่ผ่าน
ทดสอบค่าสถานะและ native getters กับ ROM จริงครบ 386 สายพันธุ์ต่อภาค ตรวจ checksum ผ่านทั้งสอง bank
ตรวจการเก็บข้อมูลส่วนสำรองและท้ายไฟล์ รวมถึงปฏิเสธข้อมูลเสีย
ยังไม่ได้ทดสอบ Safari หรือการเล่นต่อจริงในอีมูเลเตอร์
ไม่รวม ROM หรือเซฟส่วนตัวของผู้ใช้ใน ZIP

อัปเดตสถิติ Cloudflare เพื่อให้สองภาคใหม่ถูกนับ
Worker tateehack-analytics > Edit code > แทนคำสั่ง const games เดิมด้วยบรรทัดนี้ > Deploy
หากใน Worker ใช้ชื่อตัวแปร GAMES ให้คงชื่อนั้นไว้ ไม่ต้องเปลี่ยนรหัสหรือฐานข้อมูล
'''+s.splitlines()[0]+'\n')
changed=['dist/index.html','dist/admin/index.html','dist/admin/app.mjs','analytics-backend/worker.mjs'];out=Path('TATEEHACK-25-Games-FireRed-LeafGreen.zip')
with zipfile.ZipFile('TATEEHACK-23-Games-Emerald-Ruby-Sapphire.zip') as old,zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,9) as z:
 for info in old.infolist():z.writestr(info,(root/info.filename).read_bytes() if info.filename in changed else old.read(info.filename))
 for slug in ['firered','leafgreen']:
  for p in (d/slug).rglob('*'):
   if p.is_file():z.write(p,p.relative_to(root).as_posix())
 z.write(root/'FIRERED-LEAFGREEN-UPDATE-TH.txt','FIRERED-LEAFGREEN-UPDATE-TH.txt')
 for name in ['build.py','test.mjs','native.py','package.py']:z.write(root/'validation/frlg'/name,'validation/frlg/'+name)
with zipfile.ZipFile(out) as z,zipfile.ZipFile('TATEEHACK-23-Games-Emerald-Ruby-Sapphire.zip') as old:
 assert z.testzip() is None;names=set(z.namelist())
 assert set(n for n in old.namelist() if old.read(n)!=z.read(n))==set(changed)
 page=z.read('dist/index.html').decode();assert page.count('data-platform="gba"')==23;assert page.count('data-platform="nds"')==2
 admin=z.read('dist/admin/index.html').decode();assert '../private-girlshunter3/' in admin and '../private-girlshunterhalloween/' in admin
 for slug in ['firered','leafgreen']:
  base='dist/'+slug+'/'
  for n in names:
   if not n.startswith(base):continue
   assert not n.endswith(('.gba','.sav','.srm'))
   if n.endswith('.mjs'):
    for link in re.findall(r'(?:from\s*|import\s*)[\'"]([^\'"]+)',z.read(n).decode()):assert posixpath.normpath(posixpath.join(posixpath.dirname(n),link.split('?')[0])) in names
  html=z.read(base+'index.html').decode();ids=re.findall(r'\bid="([^"]+)"',html);assert len(ids)==len(set(ids));assert 'data-game="'+slug+'"' in html
  c=json.loads(z.read(base+'catalog.json'))
  for sp in c['species']:
   if sp.get('sprite'):assert base+sp['sprite'] in names
  for it in c['items']:
   if not it['unavailable']:assert it.get('sprite') and base+it['sprite'] in names
 print('PASS ZIP CRC, 25 public games, two Private games, all assets, imports and unchanged previous games')
print(out.resolve(),out.stat().st_size)
