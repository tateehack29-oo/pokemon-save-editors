from pathlib import Path
import re,struct,json,hashlib
base=Path('admin-source/validation/girlshunter3/build.py').read_text().split("for f in ['engine.mjs'")[0]
for slug,title in [('firered','FireRed'),('leafgreen','LeafGreen')]:
 s=base.replace("Path('validation/lazarus/build.py')","Path('admin-source/validation/lazarus/build.py')").replace("Path('../upload/Girls Hunter 3 Version.gba')",f"Path('upload/Pokemon - {title} Version (USA).gba')").replace("Path('dist/private-girlshunter3')",f"Path('frlg/dist/{slug}')").replace("Path('dist/fireredrocket/catalog.json')","Path('frlg/dist/fireredrocket/catalog.json')").replace("'Pokémon Girls Hunter 3'",repr('Pokémon '+title))
 if slug=='leafgreen':
  for a,b in [(0x245ee0,0x245ebc),(0x254784,0x254760),(0x2350ac,0x235088),(0x23730c,0x2372e8),(0x2380cc,0x2380a8),(0x25d7b4,0x25d790),(0x250c04,0x250be0),(0x247094,0x247070),(0x24fc40,0x24fc1c),(0x3db028,0x3dae64),(0x3d4294,0x3d40d0)]:s=s.replace(hex(a),hex(b))
 ns={};exec(s,ns);c=ns['c'];out=ns['out'];r=ns['r']
 for f in ['engine.mjs','app.mjs','index.html','style.css','pickers.mjs']:
  t=Path('frlg/dist/private-girlshunterhalloween',f).read_text().replace('Girls Hunter Halloween',title).replace('GIRLS HUNTER HALLOWEEN',title.upper()).replace('halloween1',slug+'1')
  if f=='engine.mjs':
   t=re.sub(r"ROM_SHA256='[^']+'","ROM_SHA256='"+c['romSha256']+"'",t)
   t=re.sub(r'// Girls Hunter 3[^\n]*','// Original '+title+' ROM and save format.',t)
   exp=[list(struct.unpack_from('<101I',r,(0x253ae4 if slug=='firered' else 0x253ac0)+i*404)) for i in range(6)];t=re.sub(r'const EXP_TABLE=.*?;','const EXP_TABLE='+json.dumps(exp,separators=(',',':'))+';',t)
   if slug=='leafgreen':t=t.replace('(4<<7)|(4<<11)','(4<<7)|(5<<11)')
  if f=='index.html':t=t.replace('href="../admin/"','href="../#gba"').replace('← กลับหน้า Admin','← เลือกเกม').replace('TATEEHACK / PRIVATE EDITOR','TATEEHACK / SAVE EDITOR').replace('</body>',f'<script src="../analytics-config.js?v=frlg1" defer></script><script src="../analytics.js?v=frlg1" data-game="{slug}" defer></script></body>')
  (out/f).write_text(t)
 print(slug,'extracted',sum(bool(x['base'][0]) for x in c['species']),'species')
