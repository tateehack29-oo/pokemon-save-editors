from info import *
from unicorn import *
from unicorn.arm_const import *
u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
for a,n in [(0x8000000,0x2000000),(0x2000000,0x40000),(0x3000000,0x10000),(0x4000000,0x1000),(0x5000000,0x1000),(0x6000000,0x20000)]:u.mem_map(a,n)
u.mem_write(0x8000000,r)
def call(addr,*args):
 for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(reg,v)
 u.reg_write(UC_ARM_REG_SP,0x300f000);u.reg_write(UC_ARM_REG_LR,0x300fff1);u.emu_start(addr|1,0x300fff0,count=2000000);assert u.reg_read(UC_ARM_REG_PC)==0x300fff0;return u.reg_read(UC_ARM_REG_R0)
sizes=[struct.unpack_from('<H',r,0x1148bf0+i*4+2)[0] for i in range(14)]
def load(save):
 sections={struct.unpack_from('<H',save,i*4096+4084)[0]:save[i*4096:(i+1)*4096] for i in range(14,28)}
 u.mem_write(0x3005008,struct.pack('<III',0x202552c,0x2024588,0x2029314));u.mem_write(0x2024588,sections[0][:sizes[0]]);u.mem_write(0x202552c,b''.join(sections[i][:sizes[i]] for i in range(1,5)));u.mem_write(0x2029314,b''.join(sections[i][:sizes[i]] for i in range(5,14)))
 u.mem_write(0x203b174,sections[0][0xf24:0xff0]+sections[4][0xd98:0xff0]+sections[13][0x450:0xff0]+save[30*4096:30*4096+0xff0]+save[31*4096:31*4096+0xff0]);return sections
if __name__=='__main__':
 sec=load(s)
 print('sizes',sizes)
 for id,b in sec.items():
  u.mem_write(0x2010000,b[:sizes[id]]);print('sum',id,call(0x80da1a8,0x2010000,sizes[id]),struct.unpack_from('<H',b,4086)[0])
 a=0x202552c+0x38
 print('mon',{f:call(0x803fd44,a,f,0x2010000) for f in [11,12,13,14,15,16,25,32,39,40,41,42,43,44,46]})
 print('raw',bytes(u.mem_read(a,100)).hex());old=bytes(u.mem_read(a+84,16));call(0x803e47c,a);print('stats',old.hex(),bytes(u.mem_read(a+84,16)).hex())
 print('boxes',[hex(u32(0x1148930+i*4)) for i in range(26)])
