from native import *
import json
catalog=json.loads(Path('dist/radicalred/catalog.json').read_text());load(s);v=json.loads(Path('/tmp/rr-vectors.json').read_text());a=0x2010000;fail=[]
for x in v:
 b=bytes.fromhex(x['raw']);u.mem_write(a,b)
 mode=x['mode'];u.mem_write(0x203b17a,bytes([mode!=0]));u.mem_write(0x203b3a4,struct.pack('<H',mode))
 assert call(0x803fd44,a,11,0)==x['species']
 pid=int.from_bytes(b[:4],'little');ot=int.from_bytes(b[4:8],'little');iv=int.from_bytes(b[72:76],'little');sp=catalog['species'][x['species']];ability=2 if iv>>31 else (pid&1 if sp['abilities'][1] else 0)
 assert call(0x8040d38,a)==sp['abilities'][ability],('ability',x['species'])
 assert bool(call(0x8044470,a))==(((pid>>16)^(pid&65535)^(ot>>16)^(ot&65535))<8)
 assert call(0x8042e9c,a)==pid%25
 call(0x803e47c,a);actual=bytes(u.mem_read(a+84,16))
 if actual!=b[84:100]:fail.append((x['species'],mode,b[84:100].hex(),actual.hex()))
 if x.get('pc'):
  u.mem_write(a,b);u.mem_write(a+256,b'\0'*100);call(0x90b6b78,a,a+256);assert bytes(u.mem_read(a+256,58))==bytes.fromhex(x['pc']),('pack',x['species'])
  call(0x90b6924,a+512,a+256);assert call(0x803fd44,a+512,11,0)==x['species']
print('Native stat failures',len(fail),fail[:15]);assert not fail
load(Path('/tmp/rr-edited.sav').read_bytes())
for i in range(25):
 ptr=u32(0x1148930+i*4)+29*58;call(0x90b6924,a,ptr);assert call(0x803fd44,a,11,0)==6,('box',i)
print('Native pack/unpack, all 25 PC boxes, native stats PASS',len(v))
