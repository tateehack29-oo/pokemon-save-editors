from pathlib import Path
import sys,struct,json,hashlib,re,shutil
sys.path.insert(0,'/tmp/rr-deps')
prefix=Path('validation/lazarus/build.py').read_text().split("c={'game'")[0].replace("Path('../upload/Pokemon Lazarus v2.0 - TH by CalicoNomad.gba')","Path('../upload/radicalred 4.1.gba')").replace("Path('dist/lazarus')","Path('dist/radicalred')")
exec(prefix)
c={'game':'Pokémon Radical Red 4.1','romSha256':hashlib.sha256(r).hexdigest(),'species':[],'items':[],'moves':[],'abilities':[]}
ref=json.loads(Path('dist/heartandsoul/catalog.json').read_text());dex={s['name'].upper():s['dex'] for s in ref['species'] if s.get('dex') and s['id']<=1025}
learn=u32(0x43e20)-0x8000000
for i in range(1376):
 a=0x17b98ec+i*28;n=name(r[0x14042cc+i*11:0x14042cc+(i+1)*11]);valid=bool(i and r[a] and i!=412)
 sp={'id':i,'name':n or '—','form':n,'dex':dex.get(n.upper(),i),'base':list(r[a:a+6]) if valid else [0]*6,'types':list(r[a+6:a+8]),'gender':r[a+16],'friendship':r[a+18],'growth':r[a+19],'abilities':[r[a+22],r[a+23],r[a+26]],'nameBytes':list(r[0x14042cc+i*11:0x14042cc+i*11+10])}
 if valid:
  assert sp['growth']<6 and max(sp['types'])<24,(i,sp)
  sp['sprite']=sprite(u32(0x17fa1c4+i*8),u32(0x1811208+i*8));sp['shinySprite']=sprite(u32(0x17fa1c4+i*8),u32(0x181edc8+i*8))
  ptr=u32(learn+i*4)-0x8000000;ls=[]
  for j in range(255):
   m=u16(ptr+j*3);lv=r[ptr+j*3+2]
   if lv==255 or m==65535:break
   assert m<1024 and lv<=250,(i,m,lv);ls.append([lv,m])
  assert j<254,(i,'learnset');sp['learnset']=ls
 c['species'].append(sp)
(out/'species-draft.json').write_text(json.dumps(c,ensure_ascii=False))
print('species extracted',len(c['species']))
for i in range(1013):
 a=0x11521d0+i*12;n=name(r[0x10f3188+i*13:0x10f3188+(i+1)*13]);c['moves'].append({'id':i,'name':n if i else 'ไม่มีท่า','power':r[a+1],'type':r[a+2],'accuracy':r[a+3],'pp':r[a+4],'unavailable':bool(i and ('Placeholder' in n or not n.strip(' ?-') or not 0<r[a+4]<=64 or r[a+2]>23))})
for i in range(256):
 n=name(r[0x10e32c0+i*17:0x10e32c0+(i+1)*17]);c['abilities'].append({'id':i,'name':n if i else '—'})
for i in range(750):
 a=0x13c0000+i*44;n=name(r[a:a+14]);c['items'].append({'id':i,'name':n if i else 'ไม่ถือไอเทม','pocket':r[a+26]-1,'importance':r[a+24],'sprite':sprite(u32(0x13c8100+i*8),u32(0x13c8100+i*8+4),24),'unavailable':bool(i and (not n.strip(' ?-') or not 1<=r[a+26]<=5))})
u=json.loads(Path('dist/unbound/catalog.json').read_text())
for sp in c['species']:
 i=sp['id']
 if i<len(u['species']):
  other=u['species'][i]
  if sp['name'].lower().replace('-','').replace(' ','')==other['name'].lower().replace('-','').replace(' ',''):
   sp['form']=other.get('form') or sp['name'];sp['dex']=other.get('dex',sp['dex']);sp['temporary']=other.get('temporary',False)
counts={}
for sp in c['species']:
 if sp['base'][0]:counts.setdefault(sp['name'],[]).append(sp)
for group in counts.values():
 if len(group)>1:
  for sp in group[1:]:
   sp['dex']=group[0]['dex']
   if sp['form']==sp['name']:sp['form']=sp['name']+' · Form #'+str(sp['id'])
(out/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')))
(out/'species-draft.json').unlink()
shutil.copyfile(out/c['species'][6]['sprite'],out/'cover.webp')
print('catalog ready',len(c['species']),len(c['items']),sum(not x['unavailable'] for x in c['moves']))
