import fs from 'node:fs';import assert from 'node:assert/strict';
import {SaveEditor,createPokemon,decodeMon,encodeMon,packPC,unpackPC,u16,u32} from '../../dist/radicalred/engine.mjs';
const c=JSON.parse(fs.readFileSync('dist/radicalred/catalog.json'));const raw=new Uint8Array(fs.readFileSync('../upload/radicalred 4.1.sav'));const e=new SaveEditor(raw,c);
console.log({trainer:e.trainer,money:e.money,coins:e.coins,party:e.party().map(m=>({species:m.species,level:m.level,nature:m.nature,ability:m.ability,ivs:m.ivs,evs:m.evs}))});
assert.deepEqual(e.export(),raw);assert.equal(e.partyCount,1);assert.equal(e.party()[0].species,158);assert.equal(e.party()[0].level,6);
for(let b=0;b<25;b++)assert(e.box(b).every(x=>x===null));
const trainer={id:u32(e.sb2,10),name:e.sb2.slice(0,7),gender:e.sb2[8],location:157};const vectors=[];
for(const sp of c.species.filter(x=>x.id&&x.base[0])){
 const bytes=createPokemon({species:sp.id,level:50,nature:sp.id%25},trainer,c,()=>0x12345678); const m=decodeMon(bytes,c);assert.equal(m.species,sp.id);assert.equal(m.level,50);
 vectors.push({species:sp.id,mode:0,raw:Buffer.from(bytes).toString('hex'),pc:Buffer.from(packPC(bytes)).toString('hex')});
}
for(const mode of [11,12,13])for(const species of [1,6,158,303,1000,1375]){
 const bytes=createPokemon({species,level:50,nature:species%25},trainer,{...c,statRules:{mode}},()=>0x12345678);vectors.push({species,mode,raw:Buffer.from(bytes).toString('hex')});
}
for(let nature=0;nature<25;nature++)for(const shiny of [false,true]){
 const b=encodeMon(e.mon('party:0').raw,{nature,shiny,level:37,ivs:[7,8,9,10,11,12],evs:[0,252,0,252,6,0],ability:2,heldItem:1,moves:[33,45,10,0],friendship:255,heal:true},c);const m=decodeMon(b,c);assert.equal(m.nature,nature);assert.equal(m.shiny,shiny);assert.equal(m.ability,2);vectors.push({species:158,mode:0,raw:Buffer.from(b).toString('hex')});
}
e.setTrainerName('OOTEE');e.setMoney(123456);e.setCoins(9999);e.updateMon('party:0',{level:25,nature:3,ability:2,heal:true});
for(let box=0;box<25;box++)e.addPokemon({species:6,level:50},{destination:'pc',box,slot:29});e.addPokemon({species:1,level:15});
for(let p=0;p<5;p++){const it=c.items.find(x=>x.id&&!x.unavailable&&x.pocket===p);e.addItem(it.id,it.importance?1:17);}
const exported=e.export();const reopened=new SaveEditor(exported,c);assert.equal(reopened.trainer,'OOTEE');assert.equal(reopened.money,123456);assert.equal(reopened.coins,9999);assert.equal(reopened.partyCount,2);for(let box=0;box<25;box++)assert.equal(reopened.box(box)[29].species,6);
assert.deepEqual(exported.slice(0,14*4096),raw.slice(0,14*4096));assert.deepEqual(exported.slice(28*4096,30*4096),raw.slice(28*4096,30*4096));
fs.writeFileSync('/tmp/rr-vectors.json',JSON.stringify(vectors));fs.writeFileSync('/tmp/rr-edited.sav',exported);console.log('JS roundtrip, edits, all boxes, all pockets PASS; vectors',vectors.length);
