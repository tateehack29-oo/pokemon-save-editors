# Radical Red 4.1 validation

Run from the repository root. Supply the user's ROM and save at ../upload/radicalred 4.1.gba and ../upload/radicalred 4.1.sav. These private inputs are not included.

Dependencies: Python 3, Pillow, Capstone, Unicorn, Node.js. Tests also look in /tmp/rr-deps for Python dependencies.

```
node validation/radicalred/test.mjs
python validation/radicalred/test_native.py
```

The JS tests check byte-identical no-op output, edits, 25 PC boxes, and all five pockets. Native Thumb code from the supplied ROM checks all enabled species' calculated party stats, all three custom stat modes, compressed PC records, nature, ability and shiny getters. 1,416 vectors pass.

Rebuild catalog and adapter: run build.py then adapter.py from this directory with repository root as working directory. UI text changes in the final shipped HTML are maintained separately.

Native addresses: CalculateMonStats 0x0803E47C; GetBoxMonData 0x0803FD44; GetMonAbility 0x08040D38; GetNature 0x08042E9C; IsMonShiny 0x08044470; pack PC 0x090B6B78; unpack PC 0x090B6924.
Save sizes are read from ROM 0x1148BF0. 25 box pointers at ROM 0x1148930. Expanded bag pointers at ROM 0x1147E08. Preserve original backup bank and unused bytes. Section signature 0x08012025.

No browser UI or emulator gameplay verification was performed. Randomizer-specific ability/learnset overrides have not been verified. ROM-version-specific data is used, not retail FireRed tables.
