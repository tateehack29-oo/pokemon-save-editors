from pathlib import Path
import sys,struct
sys.path.insert(0,'/tmp/rr-deps')
from capstone import *
r=Path('../upload/radicalred 4.1.gba').read_bytes();s=Path('../upload/radicalred 4.1.sav').read_bytes();u32=lambda p:struct.unpack_from('<I',r,p)[0]
c=Cs(CS_ARCH_ARM,CS_MODE_THUMB)
def show(a,n=128):
 for x in c.disasm(r[a:a+n],a+0x8000000):print(hex(x.address),x.mnemonic,x.op_str)
def refs(v):
 start=0;out=[];b=struct.pack('<I',v)
 while 1:
  p=r.find(b,start)
  if p<0:break
  out.append(hex(p));start=p+1
 return out
