import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {formCategories} from '../../dist/form-filters.mjs';
import {MON_INDEX} from '../../dist/rowe/mon-index.mjs';
const fixtures=[{id:1,name:'Charizard',dex:6},{id:2,name:'Charizard',form:'Charizard · Mega X',dex:6},{id:3,name:'Meowth',form:'Meowth Alolan',dex:52},{id:4,name:'Meganium',dex:154},{id:5,name:'Yanmega',dex:469},{id:6,name:'Rotom',dex:479},{id:7,name:'Rotom',dex:479,nativeForm:1},{id:8,name:'Pikachu',form:'Gigantamax Pikachu',dex:25},{id:9,name:'Typhlosion',form:'Hisuian Typhlosion',dex:157}];
assert.deepEqual([...formCategories(fixtures).values()],['base','mega','alola','base','base','base','other','gmax','hisui']);
const root=new URL('../../dist/',import.meta.url);
for(const dir of ['.',...fs.readdirSync(root).filter(d=>fs.existsSync(new URL(d+'/catalog.json',root)))]){
 const file=new URL((dir==='.'?'':dir+'/')+'catalog.json',root);if(!fs.existsSync(file))continue;
 const records=JSON.parse(fs.readFileSync(file)).species.filter(s=>s.id&&s.base[0]);const groups=formCategories(records);
 assert.equal(groups.size,records.length);assert(![...groups.values()].includes(undefined));
 console.log(dir,records.length,Object.fromEntries([...new Set(groups.values())].map(k=>[k,[...groups.values()].filter(v=>v===k).length])));
 const app=fs.readFileSync(new URL((dir==='.'?'':dir+'/')+'app.mjs',root),'utf8');assert(app.includes('formFilters.matches(sp)'));assert(app.includes("$('catalogList').before(formFilters.root)"));
}
assert.equal(formCategories(MON_INDEX).size,MON_INDEX.length);
console.log('ROWE',MON_INDEX.length,'PASS; all games wired');
// Exercise real click handlers without a browser or touching a save file.
class Element{constructor(tag){this.tag=tag;this.children=[];this.dataset={};this.attrs={};}setAttribute(k,v){this.attrs[k]=v;}append(x){this.children.push(x);}}
globalThis.document={createElement:tag=>new Element(tag),getElementById:()=>null,head:new Element('head')};
const {createFormFilters}=await import('../../dist/form-filters.mjs');let changes=0;
const filter=createFormFilters(fixtures,()=>changes++);
const mega=filter.root.children.find(b=>b.dataset.formGroup==='mega');mega.onclick();
assert.deepEqual(fixtures.filter(filter.matches).map(x=>x.id),[2]);assert.equal(mega.attrs['aria-pressed'],'true');
const all=filter.root.children.find(b=>b.dataset.formGroup==='all');all.onclick();assert.equal(fixtures.filter(filter.matches).length,fixtures.length);assert.equal(mega.attrs['aria-pressed'],'false');assert.equal(changes,2);
assert(!filter.root.children.some(b=>b.dataset.formGroup==='galar'));
assert.equal(formCategories([{id:1,name:'Pikachu',form:'Pikachu Alola',dex:25,nativeForm:1}]).get(1),'other');
assert.equal(formCategories([{id:1,name:'Unown',form:'Unown A',dex:201}]).get(1),'base');
console.log('Button filtering, reset, accessibility state, and absent-category hiding PASS');
