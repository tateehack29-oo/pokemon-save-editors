import json
from pathlib import Path
import sys,struct
# Requires pip install unicorn
from unicorn import *
from unicorn.arm_const import *
r=Path(sys.argv[1]).read_bytes();u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
for a,n in [(0x8000000,0x2000000),(0x2000000,0x40000),(0x3000000,0x10000),(0x4000000,0x1000),(0x5000000,0x1000),(0x6000000,0x20000)]:u.mem_map(a,n)
u.mem_write(0x8000000,r)
def call(addr,*args):
 for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(reg,v)
 u.reg_write(UC_ARM_REG_SP,0x300f000);u.reg_write(UC_ARM_REG_LR,0x300fff1);u.emu_start(addr|1,0x300fff0,count=2000000);assert u.reg_read(UC_ARM_REG_PC)==0x300fff0;return u.reg_read(UC_ARM_REG_R0)
s=Path(sys.argv[2]).read_bytes();sec={struct.unpack_from('<H',s,p+4084)[0]:s[p:p+4084] for p in range(0,81920,4096)}
sb1=sec[2]+sec[3]+sec[4]+sec[5][:520];sb2=sec[0][:3292];pc=b''.join(sec[i] for i in range(8,17))+sec[17][:4068]
u.mem_write(0x2000000,sb1);u.mem_write(0x2004000,sb2);u.mem_write(0x2010000,pc)
u.mem_write(0x300340c,struct.pack('<III',0x2000000,0x2004000,0x2010000))
cases=json.loads(Path('/tmp/er-mon-cases.json').read_text())
for m in cases:
 raw=bytes(m['raw']);a=0x2020000;u.mem_write(a,raw)
 fields={11:m['species'],12:m['heldItem'],25:m['exp'],32:m['friendship'],46:m['ability'],84:m['nature'],88:m['shinyType']}
 fields.update({13+i:v for i,v in enumerate(m['moves'])});fields.update({26+i:v for i,v in enumerate(m['evs'])});fields.update({39+i:v for i,v in enumerate(m['ivs'])})
 for f,v in fields.items():assert call(0x81a6b4c,a,f,0x2030000)==v,(m['key'],f,v)
 assert call(0x81a6190,a)==m['level']
 if len(raw)==76:
  call(0x81a5cf4,a,1,0);got=bytes(u.mem_read(a,76));assert got[52:]==raw[52:],(m['key'],got[52:].hex(),raw[52:].hex())
print('PASS native ROM getters and stat/PP recalculation for edited and created party/PC records')
# item ownership uses bitfield exactly at SB1 +0x40a
for id in [1,30,200,900]:
 before=bytearray(u.mem_read(0x2000000,len(sb1)));call(0x815475c,id);after=bytes(u.mem_read(0x2000000,len(sb1)));before[0x40a+id//8]|=1<<(id%8);assert after==bytes(before);assert call(0x8154738,id)==1
print('PASS native bag flags')
