# Elite Redux 2.65.4.1b — native verification

ROM SHA256: 926098fa9f6b29b469fa351e80e4f018285006ad10a4eb5bc255d14d6d54acfc
Complete fixture SHA256: 6ac99da8c194e9719d8ff2d4ca81bbdfc8d3e74e314474568e222829fdf6ecc8
User ROM/save are deliberately excluded from this repository and distribution.

20 sections, 4084 payload bytes, footer id/checksum/signature/counter.
Size table at ROM 0xF02610; signature 0x08012025.
SB2 section 0; SB1 sections 2–7; PC sections 8–19. Zero-size sections retained.
Single complete set in first 20 sectors; unique IDs, valid checksums, same counter required.
Remaining sectors and any 16-byte trailer preserved. No-op output is byte-identical.
Incomplete original upload is rejected; missing PC data is never synthesized.

Mon box records are unencrypted 52-byte bitfields; party records are 76 bytes.
Party count SB1+0x234; party +0x238; money +0x400; coins +0x404;
encryption key SB2+0x34; possession flags SB1+0x40A. PC starts +4, 26*30 slots.
Native ROM GetBoxMonDataInternal 0x081A6B4C; CalculateMonStatsMaster 0x081A5CF4;
GetLevelFromMonExp 0x081A6190; HasItem 0x08154738; SetItem 0x0815475C.

Verified original trainer and five species; exact no-op and healing healthy party;
edited and created mon fields read through native ROM functions;
party stat and PP bytes exactly match native recalculation;
bag changes match native SetItem; edited export roundtrip, creation in party/PC,
trainer rename, untouched sectors preserved. test.mjs creates native fixture outputs in /tmp.
Run: node validation/elite-redux/test.mjs /absolute/path/to/complete-user.sav
Native verification uses Unicorn with locally supplied ROM; see native_test.py.

Catalog: base stats at 0xC033E4 stride44; name pointer table0x9CEAFC;
learnsets0xC40060; experience0xC02744; moves0xBF9884 stride24;
items0xAC6B24 stride40; icons0xAF1FF0; abilities0xFD95E8 stride196.
Species form suffixes are joined only when enum prefix matches actual ROM name.
Reference source: https://github.com/Elite-Redux/eliteredux-source
Reference enum snapshot: ebe0df0fb9eacf878f08f3fa56317f83c477345c.

Limits: Hell mon writes blocked; final PC slot reserved; no randomizer settings changed;
Rare/Legendary preview uses normal shiny image; no emulator gameplay/browser QA performed.
