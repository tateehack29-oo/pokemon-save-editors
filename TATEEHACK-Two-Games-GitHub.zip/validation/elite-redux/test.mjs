import fs from 'node:fs';import assert from 'node:assert/strict';
import {SaveEditor,decodeMon} from '../../dist/eliteredux/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../../dist/eliteredux/catalog.json',import.meta.url)));const file=process.argv[2];if(!file)throw Error('Pass complete Elite Redux save path');
const bytes=new Uint8Array(fs.readFileSync(file)),e=new SaveEditor(bytes,c);assert.deepEqual(e.export(),bytes);assert.equal(e.trainer,'Ootee');assert.equal(e.partyCount,5);assert.deepEqual(e.party().map(x=>x.species),[4,704,599,674,77]);assert.equal(e.party()[0].level,20);
for(let i=0;i<5;i++){const m=e.mon(`party:${i}`);e.updateMon(m.key,{...m,heal:true});}
assert.deepEqual(e.export(),bytes,'Healing healthy original party must preserve bytes');
e.updateMon('party:0',{level:50,nature:10,ivs:[31,31,31,0,31,31],evs:[252,0,0,252,0,6],shinyType:3,ability:2,heldItem:1,moves:[33,45,10,108],heal:true});
e.setMoney(1234567);e.setCoins(1234);e.addItem(1);assert(e.items(c.items[1].pocket).some(x=>x.id===1));e.setItem(c.items[1].pocket,1,0,0);assert(!e.items(c.items[1].pocket).some(x=>x.id===1));
e.addPokemon({species:1,level:30,nature:3,ability:1,friendship:100,gender:'female',shinyType:2},{destination:'party'});e.addPokemon({species:25,level:40,nature:5,ability:0,shinyType:1},{destination:'pc',box:0});e.setTrainerName('OOTEE');
const out=e.export(),round=new SaveEditor(out,c);assert.equal(round.money,1234567);assert.equal(round.coins,1234);assert.equal(round.partyCount,6);assert.equal(round.trainer,'OOTEE');assert.equal(round.mon('party:0').shinyType,3);assert.equal(round.mon('party:5').gender,'female');assert.equal(round.mon('pc:0').species,25);assert.deepEqual(out.slice(20*4096),bytes.slice(20*4096));
fs.writeFileSync('/tmp/er-edited.sav',out);fs.writeFileSync('/tmp/er-mon-cases.json',JSON.stringify([...round.party(),round.mon('pc:0')].map(m=>({...m,raw:[...m.raw]}))));console.log('PASS: exact roundtrip, native fixture, edits, bag flags, party/PC creation, rename and sector preservation');
const broken=bytes.slice();broken[4090]^=1;assert.throws(()=>new SaveEditor(broken,c));
const missing=bytes.slice();missing.fill(255,19*4096,20*4096);assert.throws(()=>new SaveEditor(missing,c));
const duplicate=bytes.slice();duplicate.set(bytes.slice(0,4096),4096);assert.throws(()=>new SaveEditor(duplicate,c));
const evil=new SaveEditor(bytes,c);evil.sb2[0xc89]=(evil.sb2[0xc89]&15)|48;assert.throws(()=>evil.updateMon('party:0',{level:50}),/Hell/);
assert.throws(()=>e.updateMon('pc:779',{level:50}),/สงวน/);console.log('PASS malformed-save rejection and special-mode protection');
