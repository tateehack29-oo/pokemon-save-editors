# FireRed Rocket — TH Nonplae

ROM SHA256 d2b2dd13e75f1d0ced30760538ff723d6bd8d2e8941756d904e509fa83518993
Fixture SHA256 cd2fc351c616def974dd0aafd034a09acfcbed2e860d936974d308c8eb38a5a4
Inputs are user supplied and not distributed.

Standard encrypted, permuted Gen3 80-byte box /100-byte party records.
Native GetBoxMonData0x0803FD44 and CalculateMonStats0x0803E47C verified.
Save table0x3FEC94, sizes [3876,3968,3968,3968,3816,3968,3968,3968,3968,3968,3968,3968,3968,2000].
SB1 15720; SB2 3876; PC33744. Party0x34/0x38, currency0x290/294; key SB2+0xF20.
Native bag initialization0x08099E44 gives offsets/counts:
items0x310/42, key0x3B8/30, balls0x430/13, TM0x464/58, berries0x54C/43.
Native quantity0x08099DA0 and checksum0x080DA1A8 verified.
RAM pointer globals0x03005008/00C/010.

Species0x254784/28 and names0x245EE0/11, 386 enabled records.
Old Unown252–276 excluded; visual Unown413–439 retained for existing saves.
Front0x2350AC, palette0x23730C, shiny0x2380CC (stride8).
Learnsets0x25D7B4 with packed-u16 entries; EXP0x253AE4.
Moves0x900000/12 names0x901800/13, 512 entries, invalid placeholders hidden.
Abilities0x950000/13; items0x3DB028/44; item icons0x3D4294/8, 375 entries.

Run from repo root:
node validation/fireredrocket/test.mjs '../upload/Pokemon FireRed Rocket - TH Nonplae.sav'
python validation/fireredrocket/native_test.py '../upload/Pokemon FireRed Rocket - TH Nonplae.gba'
Native test requires unicorn. Tests write /tmp/rocket-edited.sav and vectors.
Verified exact no-op, trainer/OT rename, money/coins, bags, team/PC creation,
spare bank, tails and optional16-byte trailer, corruption rejection, all assets,
and native getters/stats for every enabled species plus edited vectors.
No browser or emulator gameplay QA. Story/Rocket rank/stealing flags are not edited.

Fairy uses type ID23 in the supplied ROM; types18–22 are unnamed/reserved.
