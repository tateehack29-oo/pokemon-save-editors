import json
from pathlib import Path
import sys,struct
# Requires pip install unicorn
from unicorn import *
from unicorn.arm_const import *
r=Path(sys.argv[1]).read_bytes();u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
for a,n in [(0x8000000,0x2000000),(0x2000000,0x40000),(0x3000000,0x10000),(0x4000000,0x1000),(0x5000000,0x1000),(0x6000000,0x20000)]:u.mem_map(a,n)
u.mem_write(0x8000000,r)
def call(addr,*args):
 for reg,v in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(reg,v)
 u.reg_write(UC_ARM_REG_SP,0x300f000);u.reg_write(UC_ARM_REG_LR,0x300fff1);u.emu_start(addr|1,0x300fff0,count=2000000);assert u.reg_read(UC_ARM_REG_PC)==0x300fff0;return u.reg_read(UC_ARM_REG_R0)
sizes=[3876,3968,3968,3968,3816,3968,3968,3968,3968,3968,3968,3968,3968,2000]
def load(save):
 sections={struct.unpack_from('<H',save,i*4096+4084)[0]:save[i*4096:(i+1)*4096] for i in range(14)}
 u.mem_write(0x3005008,struct.pack('<III',0x202552c,0x2024500,0x2029400));u.mem_write(0x2024500,sections[0][:sizes[0]]);u.mem_write(0x202552c,b''.join(sections[i][:sizes[i]] for i in range(1,5)));u.mem_write(0x2029400,b''.join(sections[i][:sizes[i]] for i in range(5,14)));return sections
sec=load(Path('/tmp/rocket-edited.sav').read_bytes())
for v in json.load(open('/tmp/rocket-vectors.json')):
 a=0x2018000;u.mem_write(a,bytes(v['raw']).ljust(100,b'\0'))
 for k,f in {'species':11,'heldItem':12,'exp':25,'friendship':32,'ability':46}.items():assert call(0x803fd44,a,f,0x2010000)==v['expected'][k],(k,v['expected']['species'])
 for k,start in [('moves',13),('ivs',39),('evs',26)]:
  for i,n in enumerate(v['expected'][k]):assert call(0x803fd44,a,start+i,0x2010000)==n,(k,i,n)
 if v['stats']:
  call(0x803e47c,a);got=bytes(u.mem_read(a+84,16));assert got==bytes(v['stats']),(v['expected']['species'],got.hex(),bytes(v['stats']).hex())
print('PASS native getters and stats for all 386 species plus edit vectors')
call(0x8099e44)
for i,(off,count) in enumerate([(0x310,42),(0x3b8,30),(0x430,13),(0x464,58),(0x54c,43)]):
 ptr=0x202552c+off;assert struct.unpack('<IB',u.mem_read(0x203988c+i*8,5))==(ptr,count)
 rows=[struct.unpack('<HH',u.mem_read(ptr+j*4,4)) for j in range(count)];assert any(id and call(0x8099da0,ptr+j*4+2)==(1 if i==1 else 10) for j,(id,q) in enumerate(rows))
for id,s in sec.items():
 u.mem_write(0x2010000,s[:sizes[id]]);assert call(0x80da1a8,0x2010000,sizes[id])==struct.unpack_from('<H',s,4086)[0]
print('PASS native bag pointers, quantities and section checksums')
