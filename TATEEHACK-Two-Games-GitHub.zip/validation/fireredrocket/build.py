from pathlib import Path
import sys,struct,json,hashlib,re,shutil
sys.path.insert(0,'/tmp/rocket-deps')
prefix=Path('validation/lazarus/build.py').read_text().split("c={'game'")[0].replace("Path('../upload/Pokemon Lazarus v2.0 - TH by CalicoNomad.gba')","Path('../upload/Pokemon FireRed Rocket - TH Nonplae.gba')").replace("Path('dist/lazarus')","Path('dist/fireredrocket')")
exec(prefix)
c={'game':'Pokémon FireRed Rocket — TH Nonplae','romSha256':hashlib.sha256(r).hexdigest(),'species':[],'items':[],'moves':[],'abilities':[]}
ref=json.loads(Path('dist/heartandsoul/catalog.json').read_text());dex={s['name'].upper():s['dex'] for s in ref['species'] if s.get('dex') and s['id']<=1025}
for i in range(440):
 a=0x254784+i*28;valid=0<i<412 and not 252<=i<=276
 n=name(r[0x245ee0+i*11:0x245ee0+(i+1)*11]) if i<412 else 'Unown' if i>412 else 'Egg'
 sp={'id':i,'name':n or '—','form':n,'dex':dex.get(n.upper(),i),'base':list(r[a:a+6]) if valid else [0]*6,'types':list(r[a+6:a+8]) if valid else [14,14],'gender':r[a+16] if valid else 255,'friendship':r[a+18] if valid else 70,'growth':r[a+19] if valid else 0,'abilities':list(r[a+22:a+24]) if valid else [0,0],'nameBytes':list(r[0x245ee0+i*11:0x245ee0+i*11+10]) if valid else []}
 if valid or i>=413:
  assert sp['growth']<6 and max(sp['types'])<24,(i,sp)
  sp['sprite']=sprite(u32(0x2350ac+i*8),u32(0x23730c+i*8));sp['shinySprite']=sprite(u32(0x2350ac+i*8),u32(0x2380cc+i*8))
 if i>=413:sp['form']='Unown '+('BCDEFGHIJKLMNOPQRSTUVWXYZ!?')[i-413];sp['dex']=201
 if valid:
  ptr=u32(0x25d7b4+i*4)-0x8000000;ls=[]
  for j in range(255):
   v=u16(ptr+j*2)
   if v==65535:break
   ls.append([v>>9,v&511])
  assert j<254,(i,'learnset');sp['learnset']=ls
 c['species'].append(sp)
for i in range(512):
 a=0x900000+i*12;n=name(r[0x901800+i*13:0x901800+(i+1)*13]);c['moves'].append({'id':i,'name':n if i else 'ไม่มีท่า','power':r[a+1],'type':r[a+2],'accuracy':r[a+3],'pp':r[a+4],'unavailable':bool(i and (not n.strip(' ?-') or r[a+4]==0))})
for i in range(1+max(max(s['abilities']) for s in c['species'])):
 n=name(r[0x950000+i*13:0x950000+(i+1)*13]);c['abilities'].append({'id':i,'name':n if i else '—'})
for i in range(375):
 a=0x3db028+i*44;n=name(r[a:a+14]);c['items'].append({'id':i,'name':n if i else 'ไม่ถือไอเทม','pocket':r[a+26]-1,'importance':r[a+24],'sprite':sprite(u32(0x3d4294+i*8),u32(0x3d4294+i*8+4),24),'unavailable':bool(i and (not n.strip(' ?-') or not 1<=r[a+26]<=5))})
(out/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')))
s=Path('dist/beyondhoenn/engine.mjs').read_text().replace('Emerald Beyond Hoenn TH. ROM-specific layout and native getters/stat calculation verified.','FireRed Rocket TH Nonplae: encrypted Gen3 records, FireRed section and bag layout verified against supplied ROM.')
s=re.sub(r"ROM_SHA256='[^']+'","ROM_SHA256='"+c['romSha256']+"'",s)
s=re.sub(r'export const SIZES=.*?;','export const SIZES=[3876,3968,3968,3968,3816,3968,3968,3968,3968,3968,3968,3968,3968,2000];',s)
s=re.sub(r'export const POCKETS=.*?;',"export const POCKETS=[{id:0,name:'ไอเทม',offset:0x310,count:42},{id:1,name:'ของสำคัญ',offset:0x3b8,count:30},{id:2,name:'โปเกบอล',offset:0x430,count:13},{id:3,name:'TM / HM',offset:0x464,count:58},{id:4,name:'เบอร์รี',offset:0x54c,count:43}];",s)
s=s.replace('new Uint8Array(15804)','new Uint8Array(15720)').replace('u32(this.sb2,0xac)','u32(this.sb2,0xf20)').replace('(3<<7)','(4<<7)')
for a,b in [('0x234','0x34'),('0x238','0x38'),('0x490','0x290'),('0x494','0x294')]:s=s.replace(a,b)
exp=[list(struct.unpack_from('<101I',r,0x253ae4+i*404)) for i in range(6)];s=re.sub(r'const EXP_TABLE=.*?;','const EXP_TABLE='+json.dumps(exp,separators=(',',':'))+';',s)
s=re.sub(r'export const TYPES=.*?;', 'export const TYPES='+'["Normal", "Fighting", "Flying", "Poison", "Ground", "Rock", "Bug", "Ghost", "Steel", "???", "Fire", "Water", "Grass", "Electric", "Psychic", "Ice", "Dragon", "Dark", "???", "???", "???", "???", "???", "Fairy"]'+';',s)
(out/'engine.mjs').write_text(s)
for f in ['app.mjs','index.html','style.css','pickers.mjs']:
 s=Path('dist/odyssey',f).read_text().replace('Odyssey v4.1','FireRed Rocket — TH Nonplae').replace('Odyssey','FireRed Rocket').replace('POKÉMON ODYSSEY','POKÉMON FIRERED ROCKET').replace('odyssey','fireredrocket').replace('?v=forms1','?v=fireredrocket1').replace('Plusle, Minun, Yggdreon','Rattata, Pidgey, Charizard')
 (out/f).write_text(s)
shutil.copyfile(out/c['species'][19]['sprite'],out/'cover.webp')
print('Extracted',sum(bool(s['base'][0]) for s in c['species']),'species,',len(c['items']),'items,',sum(not m['unavailable'] for m in c['moves']),'moves; ability max',len(c['abilities'])-1)
