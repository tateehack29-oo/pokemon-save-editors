# Heart and Soul editor 0.1

Supported ROM: `Pokemon Heart and Soul Thai - TH By Nonplae.gba`.
SHA-256: `b6f25781b0ff48b22e6b56de400de640a3cae5f0544a79ac3b8c6e03126e3fa8`.
ROM and personal saves are not distributed. All editing happens locally in the browser.

## Features

Money/coins, all six bag pockets, type-ahead held-item/move selection, item icons, normal/shiny Pokémon images, party and 14 PC boxes. Edit species, level, nature, ability slot, friendship, IVs, EVs, held item, moves and shiny; add new Pokémon to party or an empty PC slot. Catalog includes 1,427 enabled species/form records, 935 move records (including Z/Max moves), 901 items and 311 abilities. Disabled zero-stat records in the ROM are excluded. Battle-only forms/moves remain subject to the game's own rules.

Preserves trainer names and story flags. New Pokémon inherit the save owner's OT; this is not an event/Pokédex unlock tool. Accepts 128 KiB in-game saves and the same format with a 16-byte emulator trailer, preserving that trailer. Save States are not supported.

## Verified layout

- Sector payload sizes: `[3892,3968,3968,3968,3856,3968,3968,3968,3968,3968,3968,3968,3968,2400]` (ROM table `0xD578D0`).
- SB1 size 15760; SB2 size 3892; PC storage 34144. Party count `SB1+0x238`, party `+0x23C`, money `+0x494`, coins `+0x498`, XOR key `SB2+0xAC`.
- Six pockets confirmed by executing native SetBagItemsPointers (`0x1659D8`): medicine `0xE28/92`, balls `0xA04/39`, berries `0xD20/66`, items `0x564/236`, TM/HM `0xAA0/160`, keys `0x914/60` (offset/capacity).
- Encrypted/shuffled 80-byte box Pokémon and 100-byte party Pokémon; shiny threshold 8 and modifier bit 14 in u16 at offset30. Native getter `0x1BC9C8`, stats function `0x1C2C98`.
- Species `0x7E08B4`, stride268; items `0x7892B4`, stride44; moves `0x7AFF28`, stride68; abilities `0xD2F654`, stride28.
- Species flags offset144, learnset pointer152; front88, normal palette96, shiny100, female front112/palettes120/124.
- Native EXP tables copied from `0x8B1AA8`: level1 requires 1 EXP, not zero. Stat calculation respects native level50 flag and base-stat equalizer setting. Game randomizer effects may alter what is displayed in-game. Preview uses the standard shiny palette; the game's alternate shiny-color setting can differ.

Public source consulted: https://github.com/PokemonHnS-Development/pokehns-expansion . Actual supplied ROM is authoritative; source revisions may differ.

## Validation

`node tests/heartandsoul.test.mjs /absolute/path/to/supplied-sample.sav`

Optional sample is the original one with Chikorita party/Pidgey PC. Tests without argument validate the codec and creation. Sample tests check exact no-op export, six pockets, party/last PC slot, edited readback, corruption rejection, trailer and unrelated-byte preservation. Separate Unicorn tests executed the ROM's getters and CalculateMonStats on 63 records, matching JS fields and party stats. DOM integration exercised save-only upload, form search, shiny preview, adding party/PC Pokémon, export and reopening. All 18,790 catalog image references across the site were checked after byte-identical asset deduplication.

Full interactive gameplay after importing an edited save has not been tested. Export a copy and retain the original save.
