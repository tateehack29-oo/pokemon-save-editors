# Run from the parent workspace; Pillow required. User-supplied ROM is not redistributed.
from pathlib import Path
import struct,json,hashlib,functools
from PIL import Image
r=Path('upload/Pokemon Unbound - TH by Nonplae.gba').read_bytes();root=Path('wishes-editor/dist');out=root/'unbound';out.mkdir(exist_ok=True);(out/'sprites').mkdir(exist_ok=True)
assert hashlib.sha256(r).hexdigest()=='403e50caa54501cc6184493cb5bcee5aeb8bca0e632e527a404d21ae5a0bc355'
u16=lambda o:struct.unpack_from('<H',r,o)[0];u32=lambda o:struct.unpack_from('<I',r,o)[0]
def name(raw):
 c={0:' ',27:'é',171:'!',172:'?',173:'.',174:'-',180:"'",181:'♂',182:'♀',240:':',186:'/'}
 c.update({187+i:x for i,x in enumerate('ABCDEFGHIJKLMNOPQRSTUVWXYZ')});c.update({213+i:x for i,x in enumerate('abcdefghijklmnopqrstuvwxyz')});c.update({161+i:str(i) for i in range(10)})
 return ''.join(c.get(b,'?') for b in raw.split(b'\xff')[0]).strip()
@functools.lru_cache(None)
def data(ptr):
 p=ptr-0x8000000
 if not 0<=p<len(r):raise ValueError('pointer')
 if r[p]!=16:return r[p:p+2048]
 size=int.from_bytes(r[p+1:p+4],'little');p+=4;d=bytearray();assert size<=65536
 while len(d)<size:
  flags=r[p];p+=1
  for bit in range(7,-1,-1):
   if len(d)>=size:break
   if flags&(1<<bit):
    a,b=r[p:p+2];p+=2;n=(a>>4)+3;back=((a&15)<<8|b)+1
    for _ in range(n):d.append(d[-back])
   else:d.append(r[p]);p+=1
 return bytes(d[:size])
known={}
for f in root.rglob('*'):
 if f.suffix in ['.png','.webp']:
  try:
   im=Image.open(f).convert('RGBA');known[(im.size,hashlib.sha256(im.tobytes()).digest())]='../'+str(f.relative_to(root))
  except:pass
@functools.lru_cache(None)
def sprite(pic,pal,w=64):
 pixels=data(pic);colors=struct.unpack('<16H',data(pal)[:32]);rgba=[((x&31)*255//31,((x>>5)&31)*255//31,((x>>10)&31)*255//31,255 if i else 0) for i,x in enumerate(colors)];assert len(pixels)>=w*w//2
 im=Image.new('RGBA',(w,w));px=im.load()
 for y in range(w):
  for x in range(w):
   k=((y//8)*(w//8)+x//8)*32+(y%8)*4+(x%8)//2;px[x,y]=rgba[(pixels[k]>>(4*(x%2)))&15]
 h=hashlib.sha256(im.tobytes()).digest();key=(im.size,h)
 if key in known:return known[key]
 f='sprites/'+h.hex()[:24]+'.webp';im.save(out/f,lossless=True,method=6);known[key]=f;return f
ref=Path(__file__).resolve().parent/'metadata';const=json.loads((ref/'species_constants.json').read_text());dex=json.loads((ref/'pokedex_species_map.json').read_text())['species_to_dex'];namedex={s['name'].lower():s['dex'] for s in json.loads((root/'catalog.json').read_text())['species']}
c={'game':'Pokémon Unbound','romSha256':hashlib.sha256(r).hexdigest(),'species':[],'items':[],'moves':[],'abilities':[]};learn=u32(0x43e20)-0x8000000
for i in range(1294):
 a=0x19e0c9c+i*28;n=name(r[0x166a98c+i*11:0x166a98c+(i+1)*11]);token=const.get(str(i),'').replace('SPECIES_','');form=token.replace('_',' ').title() if '_' in token else n
 s={'id':i,'name':n or '—','form':form,'dex':i if 0<i<252 else dex.get(str(i),namedex.get(n.lower(),i+2000)),'base':list(r[a:a+6]),'types':list(r[a+6:a+8]),'gender':r[a+16],'friendship':r[a+18],'growth':r[a+19],'abilities':[r[a+22],r[a+23],u16(a+26)],'nameBytes':list(r[0x166a98c+i*11:0x166a98c+i*11+10]),'temporary':any(t in token for t in ['_MEGA','_PRIMAL','_GIGA','_GMAX','_ETERNAMAX'])}
 if i and s['base'][0]:
  s['sprite']=sprite(u32(0x1a1d5b4+i*8),u32(0x1a32bdc+i*8));s['shinySprite']=sprite(u32(0x1a1d5b4+i*8),u32(0x1a3f77c+i*8));p=u32(learn+i*4)-0x8000000;ls=[]
  for j in range(128):
   m=u16(p+j*3);lv=r[p+j*3+2]
   if m==0 and lv==255:break
   assert m<=922 and lv<=100,(i,m,lv)
   ls.append([lv,m])
  s['learnset']=ls
 c['species'].append(s)
for i in range(923):
 a=0xa769af+i*12;c['moves'].append({'id':i,'name':name(r[0xa40a10+i*13:0xa40a10+(i+1)*13]) if i else 'ไม่มีท่า','power':r[a+1],'type':r[a+2],'accuracy':r[a+3],'pp':r[a+4]})
for i in range(293):c['abilities'].append({'id':i,'name':name(r[0xa36398+i*17:0xa36398+(i+1)*17]) if i else '—'})
fallback={int(l.split(':',1)[0]):l.split(':',1)[1].strip() for l in (ref/'items.txt').read_text().splitlines() if ':' in l and l.split(':')[0].strip().isdigit()}
for i in range(729):
 a=0x876200+i*44;n=name(r[a:a+14]);it={'id':i,'name':fallback.get(i,n) if '?' in n else n,'pocket':r[a+26]-1,'importance':r[a+24],'sprite':sprite(u32(0x25a554+i*8),u32(0x25a554+i*8+4),24)}
 if i==0:it.update(name='ไม่ถือไอเทม',pocket=0)
 c['items'].append(it)
(out/'catalog.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':')))
print('Extracted',sum(bool(s['id'] and s['base'][0]) for s in c['species']),'species/forms;',len(c['moves'])-1,'moves;',len(c['items'])-1,'items.')
