# Sword and Shield Ultimate Plus TH Nonplae

Supported uploaded ROM SHA256: 9f6cd04a499a56a5fbb453b4f66ff45fa2b15fa5ef440983b4c093b2fe77327c.
No ROM or user save is redistributed. Browser-local editor, ninth game, route swordshield/.

Party uses native FireRed/CFRU plaintext 100-byte records. PC uses packed 58-byte records and 25 boxes; the previous 80-byte PC assumption was incorrect.
- Sizes from ROM 0x14be0d0: 3876, 4080×3, 3480, 4080×8, 1104; signature 0x08012025.
- SB1 party count +0x34, party +0x38, money +0x290 XOR SB2 +0xF20.
- Important: coins use u32 at native RAM 0x203B814, parasite offset 0x6A0, NOT vanilla SB1 +0x294. Native GetCoins 0x80D0554 jumps to 0x948AA3C. Maximum 9999.
- Five bag pockets match ROM pointer/capacity table 0x14bd2e4 and parasite offsets 0x9AC/0x10B4/0x11E0/0x12A8/0x14A8.
- Species 0x19AFBEC stride28; names 0x16184B8 stride11; 1268 records, 1240 enabled.
- Native types include Fairy=23. Abilities 0x14A9324 stride13, 255 entries.
- Moves 0x14BFA7C stride12; names 0x14B277C stride13; 896 entries including zero.
- Items 0x13C0000 stride44; 750 entries. Item illustrations reused by matching name from other existing game catalogs.
- Learnsets 0x19F4D98, 3-byte entries. EXP 0x14C24E8, growth stride1024, native level5 medium-slow134.
- Front pictures 0x19EDB5C, palettes 0x1A02128 / 0x1A0E8CC. Extracted from uploaded ROM. Alternative forms with no verified descriptive name use native name + internal ID.

Checks: byte-exact no-op, all five bag pockets, money and relocated coins, trainer/owned OT rename, existing party edits, party/last PC creation, mirror/Hall of Fame/trailer preservation, invalid input, and 3720 species/level creation cases. 47 representative vectors were executed through native ROM getters, CalculateMonStats and shiny check; results match. Native money/coin getters and five pocket addresses verified on exported save.

No full emulator gameplay continuation or visual browser QA. Keep original save. Special battle modes are not independently verified. No claim of Pokédex/event unlocks.

Source references consulted: https://github.com/Skeli789/Complete-Fire-Red-Upgrade and https://github.com/Ddaretrogamer/Sword-and-Shield-Ultimate-Plus . Supplied ROM is authoritative.

## PC fix — 2026-10-17

- Native box getter 0x0808BA18 branches to 0x09485FA4: 25 boxes, 30 slots, stride 58.
- Box pointers are read from ROM 0x014BDE10; boxes 20–25 span extra save storage, SB1 and SB2.
- Native pack: 0x09485FE4; unpack: 0x09485D98. 1,240 species/forms matched byte-for-byte in both directions.
- All 750 slots verified through the ROM getter after create/edit/rename/export.
- User recovery is a separate private save, not bundled with website sources. It restores the original empty PC and re-encodes five intended additions from the legacy records.
- Full emulator gameplay and browser UI were not exercised in this fix.
