# SoulGold GBA Thai 1.1.3 — Editor 0.1

A separate browser-only save codec for TH by Nonplae 1.1.3, added to the three-game home page. Open dist/soulgold/. Select a normal .sav/.srm (131072 bytes, optionally with the supplied emulator's 16-byte trailer). No ROM selection or upload is required.

Supported ROM SHA-256: 75fd1e351f79ad53bb388cbb75e7ec279729fdb069ff666097999bdea3d4fcba.

Features: money, coins, all eight bag pockets, existing party/PC Pokémon edits, creation in party/empty PC slots, 1,042 enabled species/form records with artwork, native ability slots, nature, level, friendship, IV/EV, shiny, healing, and live item/move suggestions with item icons. PC supports 15 base boxes and the existing BX16 extension when present. Saves from other ROM versions are not supported; checksums alone do not identify the game.

## Verified profile

- ROM species 0x7C8D04 stride 280; moves 0x76B110 stride 72; items 0x746A10 stride 44; abilities 0xEF946C stride 32.
- Section lengths: [2864,3968,3968,3968,3540,3968,3968,3968,3968,3968,3968,3968,3968,3968]. Each sector is 4096 bytes with a 3968-byte data region and separately preserved SaveBlock3 tail.
- Encryption key: SaveBlock2 0xB4. Party count: SaveBlock1 0x234; party 0x238; money 0x478; coins 0x47C; bag 0x548.
- Pokémon records: plaintext 76-byte box / 96-byte party. Native packed field bits are preserved.
- BX16 magic at storage byte 34740, box 16 at 34744; 1324 overflow bytes in sector 30 + active save-counter parity. Verify the overflow footer and checksum before reading/writing.
- Shiny threshold follows flag 0x95E (256 when set, otherwise 512), confirmed against the supplied ROM's getter.

Source reference: https://github.com/Eemeliri/soulgold . The supplied ROM and save structures take precedence over newer source changes, including newer storage extensions.

## Validation

Run `node tests/soulgold.test.mjs /path/to/sample.sav [/path/to/second.sav]`.

Passed on both supplied saves: byte-identical no-op export, unchanged Pokémon roundtrip, money/coins, all bag pockets, Pokémon changes, party creation and full-party guard, PC box 16 insertion crossing the overflow boundary, occupied slot and invalid input rejection, overflow corruption detection, checksums and export/reload. Preserved inactive slots, Hall of Fame sectors, other overflow sector, SaveBlock3, unknown fields, footer counters and the 16-byte emulator trailer.

Created every enabled species at levels 1, 50 and 100 and checked artwork and moves. DOM integration passed save loading, live item/move filtering, icons, keyboard selection, unfinished-search guard, party/PC creation, and downloaded save readback.

No emulator gameplay continuation or real mobile browser visual test was performed. Keep the original save and try an exported copy. Creation does not update Pokédex/story flags. Changing species preserves unexposed fields such as capture data, nickname and tera type; temporary forms can revert under game rules. Secondary held items and innate abilities are preserved rather than exposed as editable fields.

Artwork remains credited to Pokémon and the ROM hack contributors. No ROM or user saves are included.
