import fs from 'node:fs';import assert from 'node:assert/strict';
import {SaveEditor,createPokemon,compressMon,encodeMon,decodeMon,bits} from '../dist/quetzal/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/quetzal/catalog.json',import.meta.url)));
const trainer={id:12345,name:new Uint8Array([201,201,206,191,191,255,255]),gender:0,location:1},vectors=[];
for(let kind=0;kind<4;kind++){
 const party=createPokemon({species:25,level:30,shinyKind:kind},trainer,c,()=>123);
 for(const size of [104,88,21,28,31,38]){
  const raw=size>=88?party.slice(0,size):compressMon(party,c,size);
  let m=decodeMon(raw,c);assert.equal(m.shinyKind,kind);assert.equal(m.shiny,!!(kind&1));assert.equal(m.radiant,!!(kind&2));assert.deepEqual(encodeMon(raw,{},c),raw);
  if(size<88){assert.equal(bits(raw,44,2),kind);vectors.push({size,kind,raw:[...raw]});}
  else {assert.equal(raw[1]&3,kind);assert.equal((raw[19]>>3)&3,kind);}
  for(let target=0;target<4;target++){
   const changed=encodeMon(raw,{shinyKind:target},c);assert.equal(decodeMon(changed,c).shinyKind,target);
   const allowed=size>=88?[1,19]:[5];for(let i=0;i<raw.length;i++)if(!allowed.includes(i))assert.equal(changed[i],raw[i]);
  }
  assert.throws(()=>encodeMon(raw,{shinyKind:4},c));
 }
}
if(process.argv[2]){
 const input=new Uint8Array(fs.readFileSync(process.argv[2])),fresh=()=>new SaveEditor(input,c),e=fresh();assert.deepEqual(e.export(),input);
 const good=e.party().find(m=>!m.error);assert(good);
 for(let kind=0;kind<4;kind++){
  const t=fresh();t.updateMon(good.key,{shinyKind:kind});const out=t.export(),r=new SaveEditor(out,c);assert.equal(r.mon(good.key).shinyKind,kind);
  const inactive=(1-t.bank)*65536;assert.deepEqual(out.slice(inactive,inactive+65536),input.slice(inactive,inactive+65536));
  const existing=t.box(0).find(m=>m&&!m.error);if(existing){t.updateMon(existing.key,{shinyKind:kind});assert.equal(new SaveEditor(t.export(),c).mon(existing.key).shinyKind,kind);}
 }
 const t=fresh();const key=t.addPokemon({species:25,level:30,shinyKind:3},{destination:'pc',box:0});assert.equal(new SaveEditor(t.export(),c).mon(key).shinyKind,3);
 if(t.partyCount<6){const k=t.addPokemon({species:25,level:30,shinyKind:3},{destination:'party'});assert.equal(new SaveEditor(t.export(),c).mon(k).shinyKind,3);}
}
if(process.argv[3])fs.writeFileSync(process.argv[3],JSON.stringify(vectors));
console.log('PASS four color modes: Party/box, all four compressed layouts, transitions, no-op, invalid value rejection, optional sample preservation and insertion');
