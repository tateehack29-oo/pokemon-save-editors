import fs from 'node:fs';import assert from 'node:assert/strict';import {SaveEditor,decodeMon,encodeMon,createPokemon,POCKETS} from '../dist/darkworship/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/darkworship/catalog.json',import.meta.url))),original=new Uint8Array(fs.readFileSync(process.argv[2]));
const e=new SaveEditor(original,c);assert.equal(e.money,3000);assert.equal(e.mon('party:0').level,5);assert.equal(c.species[e.mon('party:0').species].name,'Fennekin');assert.deepEqual(e.export(),original);assert.deepEqual(encodeMon(e.mon('party:0').raw,{},c),e.mon('party:0').raw);
// Actual edits, reload and all five native expanded pockets, including sector 30.
e.setMoney(123456);e.setCoins(4321);e.updateMon('party:0',{level:50,nature:3,shiny:true,ability:2,heldItem:1,moves:[53,94,52,10],ivs:[31,30,29,28,27,26],evs:[252,0,0,0,252,6],heal:true});
for(const p of POCKETS){const item=c.items.find(x=>x.id&&x.pocket===p.id);e.addItem(item.id,item.importance?1:99);}
e.addPokemon({species:25,level:25,shiny:true},{destination:'pc',box:13,slot:29});e.addPokemon({species:1,level:10,gender:'female'},{destination:'party'});
const result=e.export(),again=new SaveEditor(result,c);assert.equal(again.money,123456);assert.equal(again.coins,4321);assert.equal(again.mon('party:0').level,50);assert.equal(again.mon('party:0').shiny,true);assert.equal(again.mon('party:0').ability,2);assert.equal(again.mon('pc:419').species,25);assert.equal(again.mon('party:1').gender,'female');assert.deepEqual(result.slice(0,14*4096),original.slice(0,14*4096));assert.deepEqual(result.slice(28*4096,30*4096),original.slice(28*4096,30*4096));
const trainer={id:0x12345678,name:new Uint8Array([201,201,206,191,191,255,255]),gender:0,location:88};let count=0;const vectors=[];
for(const sp of c.species.filter(x=>x.id&&x.base[0])){
 assert(fs.existsSync(new URL('../dist/darkworship/'+sp.sprite,import.meta.url)));assert(fs.existsSync(new URL('../dist/darkworship/'+sp.shinySprite,import.meta.url)));
 for(const level of [1,50,100]){const b=createPokemon({species:sp.id,level,shiny:level===50,nature:sp.id%25},trainer,c,()=>0x12345678);const m=decodeMon(b,c);assert.equal(m.species,sp.id);assert.equal(m.level,level);assert.equal(m.shiny,level===50);assert.equal(m.nature,sp.id%25);if(level===50&& (sp.id%29===0||[1,25,201,303,761,1405,1439].includes(sp.id)))vectors.push({raw:[...b],ability:sp.abilities[m.ability],moves:m.moves,species:sp.id});count++;}
}
const trailer=new Uint8Array(131088);trailer.set(original);trailer.fill(85,131072);assert.deepEqual(new SaveEditor(trailer,c).export(),trailer);
assert.throws(()=>again.addPokemon({species:1},{destination:'pc',box:13,slot:29}));assert.throws(()=>again.updateMon('party:0',{evs:[252,252,252,0,0,0]}));
fs.writeFileSync(process.argv[3]??'/tmp/dark-edited.sav',result);fs.writeFileSync(process.argv[4]??'/tmp/dark-vectors.json',JSON.stringify(vectors));console.log(`PASS no-op, native EXP levels, mutations, all pockets, party/PC creation, preservation, trailer, ${count} species/level creations; ${vectors.length} native vectors`);
