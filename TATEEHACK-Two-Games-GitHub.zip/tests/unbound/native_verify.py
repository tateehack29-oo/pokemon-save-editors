# Native ROM verification with Unicorn. Run from workspace parent of wishes-editor.
import sys,struct,json
sys.path.insert(0,'research/sg-deps')
from unicorn import *
from unicorn.arm_const import *
from pathlib import Path
r=Path('upload/Pokemon Unbound - TH by Nonplae(1).gba').read_bytes();s=Path('research/unbound/edited.srm').read_bytes();u=Uc(UC_ARCH_ARM,UC_MODE_THUMB)
for a,z in [(0x8000000,0x2000000),(0x2000000,0x40000),(0x3000000,0x10000),(0x4000000,0x1000),(0x5000000,0x1000),(0x6000000,0x20000),(0x7000000,0x1000)]:u.mem_map(a,z)
u.mem_write(0x8000000,r);u.mem_write(0x3005008,struct.pack('<III',0x202552c,0x2024588,0x2029314))
secs={struct.unpack_from('<H',s,j*4096+4084)[0]:j*4096 for j in range(14)};a=b=0
for i,n in enumerate([0xf24]+[0xff0]*3+[0xd98]+[0xff0]*8+[0x450]):
 addr=0x2024588 if i==0 else 0x202552c+a if i<5 else 0x2029314+b;u.mem_write(addr,s[secs[i]:secs[i]+n])
 if 0<i<5:a+=n
 if i>=5:b+=n
for addr,off,n in [(0x203b174,secs[0]+0xf24,0xcc),(0x203b240,secs[4]+0xd98,0x258),(0x203b498,secs[13]+0x450,0xba0),(0x203c038,30*4096,0xff0),(0x203d028,31*4096,0xff0)]:u.mem_write(addr,s[off:off+n])
STOP=0x300fff0

def intr(uc,no,user):
 pc=uc.reg_read(UC_ARM_REG_PC);inst=int.from_bytes(uc.mem_read(pc-2,2),'little');op=inst&255
 if op==6:
  a=uc.reg_read(UC_ARM_REG_R0);b=uc.reg_read(UC_ARM_REG_R1);a=a if a<2**31 else a-2**32;b=b if b<2**31 else b-2**32;q=int(a/b) if b else 0;uc.reg_write(UC_ARM_REG_R0,q&0xffffffff);uc.reg_write(UC_ARM_REG_R1,(a-q*b)&0xffffffff);uc.reg_write(UC_ARM_REG_R3,abs(q))
 else:raise Exception(('SWI',hex(inst),hex(pc),no))
u.hook_add(UC_HOOK_INTR,intr)
def call(addr,*args):
 for reg,val in zip([UC_ARM_REG_R0,UC_ARM_REG_R1,UC_ARM_REG_R2,UC_ARM_REG_R3],args):u.reg_write(reg,val)
 u.reg_write(UC_ARM_REG_SP,0x300f000);u.reg_write(UC_ARM_REG_LR,STOP|1);u.emu_start(addr|1,STOP,count=2000000);assert u.reg_read(UC_ARM_REG_PC)==STOP;return u.reg_read(UC_ARM_REG_R0)
e=json.loads(Path('research/unbound/edited.srm.json').read_text());assert call(0x809fd58,0x202552c+0x290)==e['money'];assert call(0x80d0554)==e['coins']
for m in e['mons']:
 kind,idx=m['key'].split(':');idx=int(idx)
 def get(k):return call(0x803fbe8,0x202552c+0x38+idx*100,k,0) if kind=='party' else call(0x808ba18,idx//30,idx%30,k,0)
 for key,f in {'species':11,'heldItem':12,'exp':25,'friendship':32,'pid':0,'ot':1}.items():assert get(f)==m[key],(m['key'],key,get(f),m[key])
 for key,start in [('moves',13),('ivs',39),('evs',26)]:assert [get(start+i) for i in range(len(m[key]))]==m[key],(m['key'],key)
 if kind=='party':
  p=0x202552c+0x38+idx*100;old=bytes(u.mem_read(p,100));call(0x803e47c,p);new=bytes(u.mem_read(p,100));assert old[84:]==new[84:],(m['key'],'stats');assert bool(call(0x8044470,p))==m['shiny']
party=Path('research/unbound/edited.srm.party').read_bytes();p=0x202552c+0x38+500;sec=next(j*4096 for j in range(14) if struct.unpack_from('<H',party,j*4096+4084)[0]==1);u.mem_write(p,party[sec+0x38+500:sec+0x38+600]);old=bytes(u.mem_read(p,100));call(0x803e47c,p);assert old[84:]==bytes(u.mem_read(p,100))[84:];assert bool(call(0x8044470,p));assert call(0x803fbe8,p,56,0)==80
print('PASS independent native ROM getters:',len(e['mons']),'party/PC; species, moves, IV/EV, identity; money/coins; recalculated party stats and shiny.')
