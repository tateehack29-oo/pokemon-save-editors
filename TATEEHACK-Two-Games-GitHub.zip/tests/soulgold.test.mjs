import assert from 'node:assert/strict';import fs from 'node:fs';import {SaveEditor,decodeMon,encodeMon,createPokemon,POCKETS,u16} from '../dist/soulgold/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/soulgold/catalog.json',import.meta.url)));
for(const file of process.argv.slice(2)){
 const original=new Uint8Array(fs.readFileSync(file)),e=new SaveEditor(original,c);assert.equal(e.money,9999999);assert.equal(e.boxCount,16);assert.equal(e.partyCount,1);assert.deepEqual(e.export(),original);
 const m=e.mon('party:0');assert.equal(m.species,656);assert.equal(m.level,5);assert.equal(m.shiny,true);assert.deepEqual(m.moves,[1,45,145,0]);assert.equal(m.ability,2);assert.equal(m.evs[3],255);
 const patch=Object.fromEntries(['species','level','nature','shiny','friendship','heldItem','moves','ivs','evs','ability'].map(k=>[k,m[k]]));assert.deepEqual(encodeMon(m.raw,patch,e.catalog),m.raw);
 const healed=encodeMon(m.raw,{heal:true},e.catalog);assert.deepEqual(healed.slice(80,96),m.raw.slice(80,96));
 e.setMoney(1234567);e.setCoins(4321);e.updateMon('party:0',{level:50,nature:10,shiny:false,heldItem:102,moves:[57,58,85,94],ivs:[1,2,3,4,5,6],evs:[252,0,0,252,6,0]});
 for(const pocket of POCKETS){const row=e.items(pocket.id).find(x=>x.id);if(row)e.setItem(pocket.id,row.slot,row.id,c.items[row.id].importance?1:12);}
 const before=e.export();const key=e.addPokemon({species:250,level:50,shiny:true},{destination:'pc',box:15,slot:12});assert.equal(key,'pc:462');assert.equal(e.mon(key).species,250);assert.equal(e.mon(key).shiny,true);assert.equal(e.mon(key).raw.length,76);
 assert.throws(()=>e.addPokemon({species:25},{destination:'pc',box:15,slot:12}),/มีโปเกมอน/);
 const out=e.export(),r=new SaveEditor(out,c);assert.equal(r.money,1234567);assert.equal(r.coins,4321);assert.equal(r.mon('party:0').level,50);assert.equal(r.mon('party:0').shiny,false);assert.equal(r.mon(key).species,250);assert.equal(r.box(15)[12].level,50);
 // Preserve inactive slot, SaveBlock3, footer IDs/counters, HOF, and emulator tail.
 const inactive=(1-e.slot)*14*4096;assert.deepEqual(out.slice(inactive,inactive+14*4096),original.slice(inactive,inactive+14*4096));assert.deepEqual(out.slice(28*4096,30*4096),original.slice(28*4096,30*4096));const other=(30+(1-e.counter%2))*4096;assert.deepEqual(out.slice(other,other+4096),original.slice(other,other+4096));assert.deepEqual(out.slice(131072),original.slice(131072));
 for(let i=e.slot*14;i<e.slot*14+14;i++){assert.deepEqual(out.slice(i*4096+3968,i*4096+4086),original.slice(i*4096+3968,i*4096+4086));assert.deepEqual(out.slice(i*4096+4088,(i+1)*4096),original.slice(i*4096+4088,(i+1)*4096));}
 // Invalid updates are atomic.
 const safe=e.export();assert.throws(()=>e.updateMon('party:0',{level:200}));assert.deepEqual(e.export(),safe);assert.throws(()=>e.updateMon('party:0',{evs:[255,255,255,0,0,0]}));assert.deepEqual(e.export(),safe);
 const bad=original.slice();bad[e.overflowOffset]^=1;assert.throws(()=>new SaveEditor(bad,c),/PC/);
 const p=new SaveEditor(original,c);for(let i=0;i<5;i++)p.addPokemon({species:25,level:5},{destination:'party'});assert.equal(p.partyCount,6);assert.throws(()=>p.addPokemon({species:25},{destination:'party'}),/เต็ม/);new SaveEditor(p.export(),c);
 console.log('PASS',file,': no-op, original-form roundtrip, exact fixture stats, money/8 pockets, fields, party creation/full guard, PC16 boundary+checksum, corruption rejection, tail and unrelated bytes.');
}
let count=0;for(const s of c.species.filter(s=>s.id&&s.base[0])){for(const level of [1,50,100]){const raw=createPokemon({species:s.id,level},{id:1234,name:new Uint8Array([187,255]),gender:0},c,()=>12345678);const m=decodeMon(raw,c);assert.equal(m.species,s.id);assert.equal(m.level,level);assert.ok(m.moves[0]);assert.ok(m.maxHP>0);}for(const k of ['sprite','shinySprite'])assert.ok(fs.existsSync(new URL('../dist/soulgold/'+s[k],import.meta.url)));count++;}console.log('PASS: creation, levels and graphics for',count,'enabled species/forms.');
