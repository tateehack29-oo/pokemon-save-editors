import fs from 'node:fs';import assert from 'node:assert/strict';
import {SaveEditor,createPokemon,encodeMon,decodeMon,experience,POCKETS,SIZES} from '../dist/heartandsoul/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/heartandsoul/catalog.json',import.meta.url)));
const trainer={id:123456789,name:new Uint8Array([201,201,206,191,191,255,255]),gender:0};
// All encryption permutations, nature/shiny combinations, long nicknames, form IDs and growth curves.
for(let i=0;i<48;i++){
 const species=[1,25,152,250,292,385,1024,1200][i%8];
 const raw=createPokemon({species,level:1+i*2,nature:i%25,shiny:!!(i%2)},trainer,c,()=>240+i);
 const m=decodeMon(raw,c);assert.equal(m.level,1+i*2);assert.equal(m.nature,i%25);assert.equal(m.shiny,!!(i%2));assert.equal(m.species,species);
 assert.deepEqual(encodeMon(raw,{},c),raw);assert.deepEqual(encodeMon(raw.slice(0,80),{},c),raw.slice(0,80));
 assert.equal(decodeMon(encodeMon(raw,{shiny:!m.shiny},c),c).shiny,!m.shiny);
}
for(let g=0;g<6;g++)assert.equal(experience(g,1),1);
assert.throws(()=>createPokemon({species:907},trainer,c)); // Native ROM disables Mega Charizard X.
if(process.argv[2]){
 const input=new Uint8Array(fs.readFileSync(process.argv[2])),e=new SaveEditor(input,c);assert.deepEqual(e.export(),input);
 assert.equal(e.partyCount,1);assert.equal(e.mon('party:0').species,152);assert.equal(e.mon('pc:0').species,16);
 for(const p of POCKETS){const item=c.items.find(x=>x.id&&x.pocket===p.id);e.addItem(item.id,item.importance?1:99);}
 e.setMoney(999999);e.setCoins(9999);e.updateMon('party:0',{level:50,shiny:true,ivs:[31,31,31,31,31,31],evs:[252,0,0,252,0,6],heldItem:4,moves:[53,85,57,94],heal:true});
 e.addPokemon({species:250,level:50},{destination:'party'});e.addPokemon({species:249,level:50},{destination:'pc',box:13,slot:29});
 assert.throws(()=>e.addPokemon({species:1},{destination:'pc',box:13,slot:29}));
 const out=e.export(),re=new SaveEditor(out,c);assert.equal(re.money,999999);assert.equal(re.coins,9999);assert.equal(re.mon('party:0').shiny,true);assert.equal(re.partyCount,2);assert.equal(re.mon('pc:419').species,249);
 const allowed=new Set();for(const [id,o] of e.sectors){for(let j=0;j<SIZES[id];j++)allowed.add(o+j);allowed.add(o+4086);allowed.add(o+4087);}for(let i=0;i<input.length;i++)if(!allowed.has(i))assert.equal(out[i],input[i]);
 const trailer=new Uint8Array(131088);trailer.set(input);trailer.fill(123,131072);assert.deepEqual(new SaveEditor(trailer,c).export(),trailer);
 const corrupt=input.slice();corrupt[e.sectors.get(1)]^=1;assert.throws(()=>new SaveEditor(corrupt,c));
}
console.log('PASS Heart and Soul codec, creation, forms, shiny, stats, six pockets, party/PC, checksum, trailer and unrelated-byte preservation.');
