import fs from 'node:fs';import assert from 'node:assert/strict';import {SaveEditor,decodeMon,encodeMon,createPokemon,compressMon,putBits} from '../dist/quetzal/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/quetzal/catalog.json',import.meta.url))),trainer={id:1234,name:new Uint8Array([201,201,206,191,191,255,255]),gender:0};
for(const size of [21,28,31,38]){
 const party=createPokemon({species:25,level:30,nature:19,shinyKind:2},trainer,c,()=>90),p=compressMon(party,c,size),m=decodeMon(p,c);assert.deepEqual(encodeMon(p,{},c),p);assert.equal(m.species,25);assert.equal(m.level,30);assert.equal(m.nickname,'Pikachu');
 if(size===28||size===38){assert.equal(m.hp,m.maxHP);putBits(p,168,10,7);putBits(p,178,14,0x123);p.set([1,2,3,4],24);const before=p.slice();const held=encodeMon(p,{heldItem:4},c);assert.deepEqual(held.slice(21),before.slice(21));const healed=decodeMon(encodeMon(p,{heal:true},c),c);assert.equal(healed.hp,healed.maxHP);assert.equal(healed.status,0);assert.deepEqual(healed.pp,healed.moves.map(i=>Math.floor(c.moves[i].pp*8/5)));const raised=decodeMon(encodeMon(p,{level:50},c),c);assert.equal(raised.hp,7+raised.maxHP-m.maxHP);assert.equal(raised.status,0x123);assert.deepEqual(raised.pp,[1,2,3,4]);}
}
if(process.env.QUETZAL_PROBLEM_SAVE){
 const input=new Uint8Array(fs.readFileSync(process.env.QUETZAL_PROBLEM_SAVE)),e=new SaveEditor(input,c);assert.equal(e.boxCount,37);assert.equal(e.pcSize,38);assert.equal(e.money,7009);assert.equal(e.legacyBag,true);assert.equal(e.partyCount,3);assert.match(e.party()[1].error,/Bad Egg/);assert.deepEqual(e.export(),input);
 const bad=e.sb1.slice(0x6a8+104,0x6a8+208);assert.throws(()=>e.updateMon('party:1',{level:50}),/Bad Egg/);assert.deepEqual(e.export(),input);
 for(let box=0;box<e.boxCount;box++)for(const m of e.box(box).filter(Boolean)){assert.ok(!m.error);assert.deepEqual(encodeMon(m.raw,{},c),m.raw);}
 e.setMoney(8000);let out=e.export();assert.equal(new SaveEditor(out,c).legacyBag,true);assert.deepEqual(new SaveEditor(out,c).sb1.slice(0x940,0x1548),e.sb1.slice(0x940,0x1548));
 e.updateMon('pc:0',{level:30,heal:true});const state=e.mon('pc:1').raw.slice(21);e.updateMon('pc:1',{heldItem:4});assert.deepEqual(e.mon('pc:1').raw.slice(21),state);
 e.addPokemon({species:384,level:50},{destination:'pc',box:36,slot:29});assert.equal(e.mon('pc:1109').hp,e.mon('pc:1109').maxHP);
 e.addItem(4,99);out=e.export();const re=new SaveEditor(out,c);assert.equal(re.legacyBag,false);assert.equal(re.items(3).find(i=>i.id===4).quantity,99);assert.deepEqual(re.sb1.slice(0x6a8+104,0x6a8+208),bad);assert.deepEqual(out.slice(65536),input.slice(65536));
 if(process.env.QUETZAL_TEST_OUTPUT)fs.writeFileSync(process.env.QUETZAL_TEST_OUTPUT,out);
 if(process.env.QUETZAL_NATIVE_VECTORS){const mons=[re.mon('pc:0'),re.mon('pc:1'),re.mon('pc:1109')];fs.writeFileSync(process.env.QUETZAL_NATIVE_VECTORS,JSON.stringify(mons));}
}
console.log('PASS: four PC layouts; battle HP/status/PP and nickname preservation; problem save opening; legacy bag; immutable Bad Egg slot; first/last PC mutation and checksum readback');
