import fs from 'node:fs';import assert from 'node:assert/strict';import {SaveEditor,createPokemon,decodeMon,defaultMoves,u32} from '../dist/engine.mjs';
const c=JSON.parse(fs.readFileSync(new URL('../dist/catalog.json',import.meta.url))),b=new Uint8Array(fs.readFileSync(process.argv[2])),fresh=()=>new SaveEditor(b,c),s=fresh();const old=s.mon('party:0').raw.slice();
const k=s.addPokemon({species:25,level:20,gender:'female',shiny:true},{destination:'party'});assert.equal(k,'party:1');assert.equal(s.partyCount,2);let m=s.mon(k);assert.equal(m.species,25);assert.equal(m.level,20);assert.equal(m.gender,'female');assert.equal(m.shiny,true);assert.equal(m.hp,m.maxHP);assert.ok(m.hp>0);assert.equal(m.ot,u32(s.sb2,10));assert.deepEqual(m.raw.slice(20,27),s.sb2.slice(0,7));assert.deepEqual(s.mon('party:0').raw,old);
const k2=s.addPokemon({species:1580,level:70},{destination:'pc',box:1,slot:19});assert.equal(k2,'pc:49');assert.equal(s.mon(k2).level,70);let r=new SaveEditor(s.export(),c);assert.equal(r.mon('party:1').gender,'female');assert.equal(r.mon('pc:49').species,1580);assert.deepEqual(r.mon('party:0').raw,old);
let before=s.export();assert.throws(()=>s.addPokemon({species:1},{destination:'pc',box:1,slot:19}));assert.deepEqual(s.export(),before);
while(s.partyCount<6)s.addPokemon({species:1},{destination:'party'});before=s.export();assert.throws(()=>s.addPokemon({species:1},{destination:'party'}));assert.deepEqual(s.export(),before);
for(let i=0;i<30;i++)s.addPokemon({species:133},{destination:'pc',box:13});before=s.export();assert.throws(()=>s.addPokemon({species:133},{destination:'pc',box:13}));assert.deepEqual(s.export(),before);new SaveEditor(before,c);
assert.throws(()=>s.addPokemon({species:1435},{destination:'pc'}));assert.throws(()=>s.addPokemon({species:1,evs:[252,252,252,252,252,252]},{destination:'pc'}));
const trainer={id:12345,name:new Uint8Array([187,188,255,255,255,255,255]),gender:0,location:209};let count=0;
for(const sp of c.species.filter(x=>x.id&&x.base[0])){
 for(const level of [1,50,100]){const raw=createPokemon({species:sp.id,level,shiny:level===100},trainer,c,()=>0x1234abcd);const m=decodeMon(raw,c);assert.equal(m.species,sp.id);assert.equal(m.level,level);assert.equal(m.shiny,level===100);assert.equal(m.hp,m.maxHP);assert.ok(m.hp>0);assert.ok(m.moves[0]>0);assert.ok(m.pp[0]>0);assert.equal(m.nature,0);}
 assert.ok(sp.sprite&&sp.shinySprite);assert.ok(fs.existsSync(new URL('../dist/'+sp.sprite,import.meta.url)));count++;
}
console.log(`PASS: all ${count} species/forms created at Lv.1, 50, 100; sprites present; OT, gender, shiny, moves and stats; party and PC insertion; cross-sector PC save; full/occupied slot rejection and unchanged original Pokémon.`);
