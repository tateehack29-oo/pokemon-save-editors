import fs from 'node:fs';import assert from 'node:assert/strict';import path from 'node:path';
import {SaveEditor,createPokemon,decodeMon,encodeMon,compressMon,checksum,u16,u32,POCKETS,experience} from '../dist/quetzal/engine.mjs';
const root=new URL('../dist/quetzal/',import.meta.url),c=JSON.parse(fs.readFileSync(new URL('catalog.json',root)));
assert.equal(c.species.length,1529);assert.equal(c.moves.length,849);assert.equal(c.items.length,890);
for(const s of c.species.slice(1)){assert.ok(fs.existsSync(new URL(s.sprite,root)));assert.ok(fs.existsSync(new URL(s.shinySprite,root)));}
for(const i of c.items)if(i.sprite)assert.ok(fs.existsSync(new URL(i.sprite,root)));
const trainer={id:0x12345678,name:new Uint8Array([201,201,206,191,191,255,255]),gender:0};
for(const sp of c.species.slice(1)){
 const r=createPokemon({species:sp.id,level:100,nature:19,shinyKind:2},trainer,c,()=>90),m=decodeMon(r,c);assert.equal(m.level,100);assert.equal(m.shinyKind,2);assert.equal(m.hp,m.maxHP);assert.deepEqual(encodeMon(r,{},c),r);
 const p=compressMon(r,c),pm=decodeMon(p,c);assert.equal(pm.species,sp.id);assert.equal(pm.level,100);assert.equal(pm.shinyKind,2);assert.deepEqual(pm.moves,m.moves);assert.deepEqual(encodeMon(p,{},c),p);
}
for(const level of [1,5,75]){const r=createPokemon({species:384,level},trainer,c,()=>90),m=decodeMon(compressMon(r,c),c);assert.equal(m.level,level);assert.ok(m.exp>=experience(c.species[384].growth,level));}
const savePath=process.env.QUETZAL_SAVE;if(savePath){
 const input=new Uint8Array(fs.readFileSync(savePath)),e=new SaveEditor(input,c);assert.deepEqual(e.export(),input);assert.equal(e.money,1000000);assert.equal(e.boxCount,45);assert.equal(e.mon('party:0').species,1264);assert.equal(e.mon('party:0').shinyKind,2);
 const orig=e.mon('party:0');e.updateMon('party:0',{species:orig.species,level:orig.level,nature:orig.nature,ability:orig.ability,friendship:orig.friendship,heldItem:orig.heldItem,shinyKind:orig.shinyKind,ivs:orig.ivs,evs:orig.evs,moves:orig.moves,heal:false});assert.deepEqual(e.export(),input);
 e.setMoney(7654321);e.setCoins(1234);e.updateMon('party:0',{level:75,ivs:[31,31,31,31,31,31],evs:[252,4,0,0,252,0],heal:true});
 for(const [box,slot] of [[0,0],[3,1],[44,29]]){const key=e.addPokemon({species:384,level:100,shinyKind:1},{destination:'pc',box,slot});assert.equal(e.mon(key).level,100);assert.throws(()=>e.addPokemon({species:25},{destination:'pc',box,slot}));}
 for(let i=0;i<5;i++)e.addPokemon({species:25,level:10});assert.throws(()=>e.addPokemon({species:25}));assert.equal(e.partyCount,6);
 e.addItem(4,9999);e.addItem(703,1);e.setItem(3,0,1,777);const oldKeyItems=e.items(11).length;e.addItem(704,1);assert.equal(e.items(11).length,oldKeyItems);
 assert.throws(()=>e.addItem(703,2));assert.throws(()=>e.updateMon('pc:0',{evs:[1,0,0,0,0,0]}));
 const out=e.export(),re=new SaveEditor(out,c);assert.equal(re.money,7654321);assert.equal(re.coins,1234);assert.equal(re.mon('party:0').level,75);assert.equal(re.mon('pc:1349').species,384);assert.equal(re.pool().find(x=>x.id===4).quantity,9999);assert.equal(re.pool().find(x=>x.id===1).quantity,777);assert.deepEqual(out.slice(16*4096),input.slice(16*4096));
 const bad=input.slice();bad[e.sectors.get(1)]^=1;assert.throws(()=>new SaveEditor(bad,c),/checksum/);
 const removed=new SaveEditor(input,c);const item=removed.items(3)[0];removed.setItem(3,item.slot,0,0);assert.equal(new SaveEditor(removed.export(),c).items(3).length,0);
 if(process.env.QUETZAL_TEST_OUTPUT)fs.writeFileSync(process.env.QUETZAL_TEST_OUTPUT,out);
}
console.log('Quetzal: catalog, 1,528 species, PC compression, no-op, mutation, bounds, bag and checksums passed');
