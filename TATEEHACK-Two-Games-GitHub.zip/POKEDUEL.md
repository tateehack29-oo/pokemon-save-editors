# Yu-Gi-Oh POKEDUEL V4.0.6 — PokeAndroid

เพิ่มเป็นเกมที่ 12 โดยใช้หน้าตาเดียวกับภาคอื่น
- อ่านเซฟจากเมนูในเกมขนาด 128 KB และแบบต่อท้าย 16 ไบต์
- แก้ชื่อผู้เล่น เงิน เหรียญ ทีม กล่อง PC ไอเทม เลเวล Nature Ability IV/EV ท่า และไชนี่
- เพิ่มมอนสเตอร์ลงทีม/PC และเลือกส่งออก .sav หรือ .srm
- ประมวลผลไฟล์ในอุปกรณ์ ไม่ส่งเซฟหรือ ROM ขึ้นเซิร์ฟเวอร์

ทดสอบเซฟ Ootee ที่ให้มา: อ่าน B Chick เลเวล 6 เงิน 4,000 ได้ และส่งออกแบบไม่แก้ไขตรงต้นฉบับทุกไบต์
ทดสอบสร้างมอนสเตอร์ 4,959 กรณี พร้อมตรวจค่าจากโค้ด ROM โดยตรง 457 ตัวอย่าง รวมถึงกระเป๋า 5 หมวด
ยังไม่ได้ทดสอบนำเซฟกลับเข้าเล่นจริงใน emulator และยังไม่ได้ตรวจ UI ผ่านเบราว์เซอร์
รองรับ ROM ฉบับที่ให้มาโดยเฉพาะ ไม่รับประกัน ROM รุ่นอื่นหรือ save state

## อัปโหลดเว็บไซต์
ดาวน์โหลด ZIP ชุดใหม่ แล้วเปลี่ยนชื่อเป็น TATEEHACK-Two-Games-GitHub.zip ก่อนอัปโหลดทับไฟล์เดิมใน GitHub
กด Commit changes และรอ Actions ของ commit ล่าสุดเป็นสีเขียว

## อัปเดตสถิติ
Cloudflare Worker ต้องมี pokeduel ในรายการ games ด้วย
เปิด Edit code แล้วแทนที่เฉพาะคำประกาศ const games เดิมทั้งหมด (ตั้งแต่ const games จนถึง ];) ด้วย:

```js
const games=['home','rowe','wishes','soulgold','quetzal','darkworship','heartandsoul','unbound','originheartgold','swordshield','digimon','moonblack2','pokeduel'];
```

กด Deploy โดยคงโค้ดส่วนอื่น DB และตัวแปรเดิมไว้
ใน ZIP มี analytics-backend/worker.mjs ฉบับอัปเดตด้วย
